package com.hotel.exception;
public class HotelException extends Exception{

    /**
 * 
 */
private static final long serialVersionUID = 8808419149400977939L;

    public HotelException(String message)
    {
        super(message);
    }
}