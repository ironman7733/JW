package com.hotel.dao;

public class QueryMapper {
    
public static final String INSERT_QUERY="insert into hotel_table(hotelid,hotelname,hotellocation,hotelemail,hotelmobile,hotelstatus) values(hid_seq.nextval,?,?,?,?,'N')";
public static final String SELECT_ID_QUERY="select hid_seq.currval from dual";
public static final String UPDATE_QUERY="update hotel_table set hotelstatus = 'Y' where hotelemail=?";

}