package com.cg.hms.util;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.hms.exception.HotelException;



public class DBConnection {
	
	public static Connection getConnection()throws HotelException
	{
		
		Connection con=null;
		Properties p=new Properties();
			try {
				FileReader f=new FileReader("resources/jdbc.properties");
				p.load(f);
				String driver=p.getProperty("driver");
				String url=p.getProperty("dburl");
				String user=p.getProperty("dbuser");
				String pass=p.getProperty("dbpass");
				Class.forName(driver);
				con=DriverManager.getConnection(url, user, pass);
					return con;
			} catch (FileNotFoundException e) {
				throw new HotelException("Unable to connect to date base "+e.getMessage());
			} catch (ClassNotFoundException e) {
				throw new HotelException("Unable to connect to date base "+e.getMessage());
			} catch (IOException e) {
				throw new HotelException("Unable to connect to date base "+e.getMessage());
			} catch (SQLException e) {
				throw new HotelException("Unable to connect to date base "+e.getMessage());
			}
		

	}

}
