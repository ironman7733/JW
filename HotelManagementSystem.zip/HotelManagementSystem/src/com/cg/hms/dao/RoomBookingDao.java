package com.cg.hms.dao;

import java.util.List;

import com.cg.hms.exception.HotelException;
import com.cg.hms.bean.Booking;
import com.cg.hms.bean.Hotels;
import com.cg.hms.bean.RoomBean;

public interface RoomBookingDao {
	
	public abstract List<Hotels> viewAllHotels() throws HotelException;
	public abstract List<RoomBean> viewAvailableRooms(int hotelId) throws HotelException;
	public  abstract int bookRoom(RoomBean r,String username,Booking b) throws HotelException;
	public  abstract double getFare(int roomId) throws HotelException;
	public abstract Booking viewBookingStatus(int bookingId) throws HotelException;
	

}
