package com.cg.hms.dao;

public interface QueryMapper {
	
	public static final String validateUser="select username,password,role from users where username=? and password=?";
	public static final String addHotel="insert into hotels(HOTELID,HOTELNAME,HOTELADDRESS, HOTELDESCRIPTION,AVGRATEPERNIGHT,PHONENO,HOTELRATING,HOTELEMAIL,CITY)values(hId.nextval,?,?,?,?,?,?,?,?)";
	public static final String updateHotel="update hotels set  HOTELNAME=?,HOTELADDRESS=?, HOTELDESCRIPTION=?, AVGRATEPERNIGHT=?, PHONENO=?, HOTELRATING=?, HOTELEMAIL=?, CITY=? where HOTELID=?";
	public static final String listHotels="select HOTELID,HOTELNAME,HOTELADDRESS, HOTELDESCRIPTION,AVGRATEPERNIGHT,PHONENO,HOTELRATING,HOTELEMAIL,CITY from hotels ";
	public static final String deleteHotel="delete from hotels where HOTELID=?";
	public static final String listRooms="select HOTEL_ID, ROOM_ID,ROOM_NO,ROOM_TYPE,PER_NIGHT_RATE,AVAILABILITY from rooms where AVAILABILITY='Y' and HOTEL_ID=? ";
	public static final String getRoomFare="select PER_NIGHT_RATE from rooms where ROOM_ID=? ";
	public static final String bookRoom="update rooms set AVAILABILITY='N' where ROOM_ID=? and  HOTEL_ID=?";
	public static final String entryBookingDetails="insert into BookingDetails(BOOKING_ID,USERNAME,BOOKED_FROM,BOOKED_TO,NO_OF_ADULTS, NO_OF_CHILDREN,AMOUNT,ROOM_ID,HOTEL_ID)values(bookingId.nextval,?,?,?,?,?,?,?,?)";
	public static final String getBookingId="select bookingId.currval from dual ";
	public static final String getBookingStatus="select BOOKING_ID,USERNAME,BOOKED_FROM,BOOKED_TO,NO_OF_ADULTS, NO_OF_CHILDREN,AMOUNT,ROOM_ID,HOTEL_ID from BookingDetails where BOOKING_ID=?";
	public static final String getGuestList="select BOOKING_ID,USERNAME,BOOKED_FROM,BOOKED_TO,NO_OF_ADULTS, NO_OF_CHILDREN,AMOUNT,ROOM_ID,HOTEL_ID from BookingDetails";
	public static final String registerUser="insert into users (USERNAME,PASSWORD,FULLNAME,ROLE,MOBILENO,ADDRESS,EMAILID)values(?,?,?,'user',?,?,?)";
	public static final String addRooms="insert into rooms (ROOM_ID,HOTEL_ID,ROOM_NO,ROOM_TYPE,PER_NIGHT_RATE,AVAILABILITY) values(rId.nextval,?,?,?,?,'Y')";
	public static final String viewRooms="select ROOM_ID,HOTEL_ID,ROOM_NO,ROOM_TYPE,PER_NIGHT_RATE,AVAILABILITY from rooms where HOTEL_ID=?";
	public static final String updateRoom="update rooms set ROOM_NO=?,ROOM_TYPE=?,PER_NIGHT_RATE=?,AVAILABILITY=? where HOTEL_ID=? and ROOM_ID=?";
	public static final String deleteRoom="delete from rooms where ROOM_ID=?";
	public static final String getBookings="select BOOKING_ID,USERNAME,BOOKED_FROM,BOOKED_TO,NO_OF_ADULTS, NO_OF_CHILDREN,AMOUNT,ROOM_ID,HOTEL_ID from BookingDetails where HOTEL_ID=?";
	public static final String getGuestListByHotel="select distinct users.username,users.emailid,users.address,users.mobileno from users  join  BookingDetails on users.username=BookingDetails.username where BookingDetails.hotel_Id=?";
	public static final String registerEmployee="insert into users (USERNAME,PASSWORD,FULLNAME,ROLE,MOBILENO,ADDRESS,EMAILID)values(?,?,?,'employee',?,?,?)";
	
}
