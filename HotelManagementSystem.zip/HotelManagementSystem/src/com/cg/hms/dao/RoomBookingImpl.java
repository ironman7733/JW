package com.cg.hms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.hms.bean.Booking;
import com.cg.hms.bean.Hotels;
import com.cg.hms.bean.RoomBean;
import com.cg.hms.exception.HotelException;
import com.cg.hms.util.DBConnection;

public class RoomBookingImpl implements RoomBookingDao {
	
	public static Logger log=Logger.getLogger(RoomBookingImpl.class);
	
	 public RoomBookingImpl() {
		
	}

	@Override
	public List<Hotels> viewAllHotels() throws HotelException {
		Connection con=null;
		List<Hotels> list=new ArrayList<Hotels>();
		
		try {
			con=DBConnection.getConnection();
			PreparedStatement pstmt=con.prepareStatement(QueryMapper.listHotels);
			ResultSet r=pstmt.executeQuery();
			while(r.next())
			{
				Hotels h=new Hotels();
				h.setHotelId(r.getInt("HOTELID"));
				h.setHotelName(r.getString("HOTELNAME"));
				h.setHotelAddress(r.getString("HOTELADDRESS"));
				/*h.setHotelDescription(r.getString("HOTELDESCRIPTION"));
				h.setHotelEmail(r.getString("HOTELEMAIL"));
				h.setHotelRating(r.getString("HOTELRATING"));
				h.setPhoneNo(r.getString("PHONENO"));*/
				h.setAverageRate(r.getDouble("AVGRATEPERNIGHT"));
				h.setCity(r.getString("CITY"));
				
				list.add(h);
				
			}
			
					
		} catch (SQLException e) {
			throw new HotelException("Failed to Show "+e.getMessage());
		} catch (Exception e) {
			throw new HotelException("Failed to Show "+e.getMessage());
		}
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				throw new HotelException("Connection cannot be terminated"+e.getMessage());
			}
		}
		return list;
	}

	@Override
	public List<RoomBean> viewAvailableRooms(int hotelId) throws HotelException {
		Connection con=null;
		List<RoomBean>roomList=new ArrayList<RoomBean>();
		try {
			con=DBConnection.getConnection();
			PreparedStatement pstmt=con.prepareStatement(QueryMapper.listRooms);
			pstmt.setInt(1, hotelId);
			ResultSet r=pstmt.executeQuery();
			while(r.next())
			{
				RoomBean room=new RoomBean();
				room.setHotelId(r.getInt("HOTEL_ID"));
				room.setRoomId(r.getInt("ROOM_ID"));
				room.setRoomNo(r.getString("ROOM_NO"));
				room.setRoomType(r.getString("ROOM_TYPE"));
				room.setRatePerNight(r.getDouble("PER_NIGHT_RATE"));
				roomList.add(room);
			}
		} catch (SQLException e) {
			throw new HotelException("Failed to Show "+e.getMessage());
		} catch (Exception e) {
			throw new HotelException("Failed to Show "+e.getMessage());
		}
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				throw new HotelException("Connection cannot be terminated"+e.getMessage());
			}
		}
		return roomList;
	}

	@Override
	public int bookRoom(RoomBean r,String username,Booking b) throws HotelException {
		int bId=0;
		
		Connection con=null;
		try {
			con=DBConnection.getConnection();
			PreparedStatement pstmt=con.prepareStatement(QueryMapper.bookRoom);
			pstmt.setInt(1, r.getRoomId());
			pstmt.setInt(2, r.getHotelId());
			int count=pstmt.executeUpdate();
			if(count>0)
			{
				//System.out.println("Your Room is Booked");
				PreparedStatement pstmt1=con.prepareStatement(QueryMapper.entryBookingDetails);
				pstmt1.setString(1, username);
				pstmt1.setInt(8, b.getHotelId());
				java.sql.Date startDate=new java.sql.Date(b.getBookedFrom().getTime());
				java.sql.Date endDate=new java.sql.Date(b.getBookedTo().getTime());
				pstmt1.setDate(2, startDate);
				pstmt1.setDate(3, endDate);
				pstmt1.setInt(4, b.getAdultNo());
				pstmt1.setInt(5, b.getChildrenNo());
				pstmt1.setDouble(6, b.getAmount());
				pstmt1.setInt(7, r.getRoomId());
				int count1=pstmt1.executeUpdate();
				if(count1>0)
				{
					PreparedStatement pstmt2=con.prepareStatement(QueryMapper.getBookingId);
					ResultSet r1=pstmt2.executeQuery();
					if(r1.next())
						 bId=r1.getInt(1);
					
				}
																		
			}
		} catch (SQLException e) {
		throw new HotelException("Unable to Book Rooms "+e.getMessage());
		} catch (Exception e) {
			throw new HotelException("Unable to Book Rooms "+e.getMessage());
		}
		finally{
			try {
				con.close();
			} catch (SQLException e) {
				throw new HotelException("Connection cannot be terminated"+e.getMessage());
			}
		}
		return bId;
	}

	@Override
	public double getFare(int roomId) throws HotelException {
		
		double amount=0;
		Connection con=null;
		try {
			con=DBConnection.getConnection();
			
			PreparedStatement pstmt1=con.prepareStatement(QueryMapper.getRoomFare);
			pstmt1.setInt(1, roomId);
			ResultSet r=pstmt1.executeQuery();
			if(r.next())
				amount=r.getDouble("PER_NIGHT_RATE");
		} catch (SQLException e) {
			throw new HotelException("Failed to retreive room fare"+e.getMessage());
		} catch (Exception e) {
			throw new HotelException("Failed to retreive room fare"+e.getMessage());
		}	
		finally{
			try {
				con.close();
			} catch (SQLException e) {
				throw new HotelException("Connection cannot be terminated"+e.getMessage());
			}
			
		}
			
			return amount;
	}

	@Override
	public Booking viewBookingStatus(int bookingId) throws HotelException {
		Booking b=null;
		Connection con=null;
		try {
			con=DBConnection.getConnection();
			PreparedStatement pstmt=con.prepareStatement(QueryMapper.getBookingStatus);
			pstmt.setInt(1, bookingId);
			ResultSet r=pstmt.executeQuery();
			if(r.next())
			{
				b=new Booking();
				b.setRoomId(r.getInt("ROOM_ID"));
				b.setUserName(r.getString("USERNAME"));
				b.setBookedFrom(r.getDate("BOOKED_FROM"));
				b.setBookedTo(r.getDate("BOOKED_TO"));
				b.setAdultNo(r.getInt("NO_OF_ADULTS"));
				b.setChildrenNo(r.getInt("NO_OF_CHILDREN"));
				b.setBookingId(r.getInt("BOOKING_ID"));
				b.setAmount(r.getDouble("AMOUNT"));
				b.setHotelId(r.getInt("HOTEL_ID"));
			}
		} catch (SQLException e) {
			throw new HotelException("Unable to view the booking status "+e.getMessage());
		} catch (Exception e) {
			throw new HotelException("Unable to view the booking status "+e.getMessage());
		}
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				throw new HotelException("Connection cannot be terminated"+e.getMessage());
			}
		}
		return b;
	}

	
	
	
}

	
		
		
	


