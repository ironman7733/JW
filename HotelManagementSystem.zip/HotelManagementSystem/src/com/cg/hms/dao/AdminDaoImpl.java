package com.cg.hms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;




import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.hms.bean.Booking;
import com.cg.hms.bean.Hotels;
import com.cg.hms.bean.RoomBean;
import com.cg.hms.bean.User;
import com.cg.hms.exception.HotelException;
import com.cg.hms.util.DBConnection;

public class AdminDaoImpl implements AdminDao {
	
	public static Logger log=Logger.getLogger(AdminDaoImpl.class);

	 public AdminDaoImpl() {
		
		 PropertyConfigurator.configure("resources/log4j.properties");
	}

	@Override
	public int addHotel(Hotels h) throws HotelException {
		log.debug("Add Hotel");
		int count = 0;
		Connection con = null;
		try {
			con = DBConnection.getConnection();
			log.debug("Connection Established");
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.addHotel);
			pstmt.setString(1, h.getHotelName());
			pstmt.setString(2, h.getHotelAddress());
			pstmt.setString(3, h.getHotelDescription());
			pstmt.setDouble(4, h.getAverageRate());
			pstmt.setString(5, h.getPhoneNo());
			pstmt.setString(6, h.getHotelRating());
			pstmt.setString(7, h.getHotelEmail());
			pstmt.setString(8, h.getCity());

			count = pstmt.executeUpdate();
			log.info("Hotel Added");
		} catch (SQLException e) {
			log.error(e.getMessage());
			throw new HotelException("Failed to Add Hotel " + e.getMessage());
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new HotelException("Failed to Add Hotel " + e.getMessage());
		} finally {
			try {
				con.close();
				log.info("Connection terminated");
			} catch (SQLException e) {
				throw new HotelException("Connection cannot be terminated"+e.getMessage());
			}
		}
		return count;
	}

	@Override
	public int updateHotel(Hotels h) throws HotelException {
		Connection con = null;
		int count = 0;
		log.debug("Update Hotel");
		try {
			con = DBConnection.getConnection();
			log.debug("Connection Established");
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.updateHotel);
			pstmt.setString(1, h.getHotelName());
			pstmt.setString(2, h.getHotelAddress());
			pstmt.setString(3, h.getHotelDescription());
			pstmt.setDouble(4, h.getAverageRate());
			pstmt.setString(5, h.getPhoneNo());
			pstmt.setString(6, h.getHotelRating());
			pstmt.setString(7, h.getHotelEmail());
			pstmt.setString(8, h.getCity());
			pstmt.setInt(9, h.getHotelId());

			count = pstmt.executeUpdate();
			log.info("Hotel Updated");
			
		} catch (SQLException e) {
			throw new HotelException("Failed to Update Hotel"+e.getMessage());
		} catch (Exception e) {
			throw new HotelException("Failed to Update Hotel"+e.getMessage());

		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				throw new HotelException("Connection cannot be terminated"+e.getMessage());
			}
		}

		return count;
	}

	@Override
	public List<Hotels> viewAllHotels() throws HotelException {
		Connection con = null;
		List<Hotels> list = new ArrayList<Hotels>();
		log.debug("View Hotel");
		try {
			con = DBConnection.getConnection();
			log.debug("Connection Established");
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.listHotels);
			ResultSet r = pstmt.executeQuery();
			while (r.next()) {
				Hotels h = new Hotels();
				h.setHotelId(r.getInt("HOTELID"));
				h.setHotelName(r.getString("HOTELNAME"));
				h.setHotelAddress(r.getString("HOTELADDRESS"));
				h.setHotelDescription(r.getString("HOTELDESCRIPTION"));
				h.setHotelEmail(r.getString("HOTELEMAIL"));
				h.setHotelRating(r.getString("HOTELRATING"));
				h.setPhoneNo(r.getString("PHONENO"));
				h.setAverageRate(r.getDouble("AVGRATEPERNIGHT"));
				h.setCity(r.getString("CITY"));

				list.add(h);

			}
			log.info("Hotel List successfully");
		} catch (SQLException e) {
			throw new HotelException("Failed to Show " + e.getMessage());
		} catch (Exception e) {
			throw new HotelException("Failed to Show " + e.getMessage());
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				throw new HotelException("Connection cannot be terminated"+e.getMessage());
			}
		}
		return list;
	}

	@Override
	public int deleteHotel(int hotelId) throws HotelException {
		log.debug("Delete Hotel");
		Connection con = null;
		int count = 0;
		try {
			con = DBConnection.getConnection();
			log.debug("Connection Established");
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.deleteHotel);
			pstmt.setInt(1, hotelId);
			count = pstmt.executeUpdate();
			log.info("Hotel Deleted");
		
		} catch (SQLException e) {
			throw new HotelException("Failed to delete Hotel " + e.getMessage());
		} catch (Exception e) {
			throw new HotelException("Failed to delete Hotel " + e.getMessage());
		}

		finally {
			try {
				con.close();
			} catch (SQLException e) {
				throw new HotelException("Connection cannot be terminated"+e.getMessage());
			}
		}
			return count;
	}

	@Override
	public List<Booking> viewGuestList() throws HotelException {
		log.debug("Guest List");
		List<Booking> guestList = new ArrayList<Booking>();
		Connection con = null;
		try {
			con = DBConnection.getConnection();
			log.debug("Connection Established");
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.getGuestList);
			ResultSet r = pstmt.executeQuery();
			while (r.next()) {
				Booking b = new Booking();
				b.setBookingId(r.getInt("BOOKING_ID"));
				b.setHotelId(r.getInt("HOTEL_ID"));
				b.setRoomId(r.getInt("ROOM_ID"));
				b.setUserName(r.getString("USERNAME"));
				b.setBookedFrom(r.getDate("BOOKED_FROM"));
				b.setBookedTo(r.getDate("BOOKED_TO"));
				b.setAdultNo(r.getInt("NO_OF_ADULTS"));
				b.setChildrenNo(r.getInt("NO_OF_CHILDREN"));
				b.setAmount(r.getDouble("AMOUNT"));
				guestList.add(b);
			}
			log.info("GuestList Successfull");
		} catch (SQLException e) {
			throw new HotelException("Unable to display the GuestList "+ e.getMessage());
		} catch (Exception e) {
			throw new HotelException("Unable to display the GuestList "+ e.getMessage());
		}
		finally{
			try {
				con.close();
			} catch (SQLException e) {
				throw new HotelException("Connection cannot be terminated"+e.getMessage());
			}
		}

		return guestList;
	}

	@Override
	public int addRooms(RoomBean room) throws HotelException {
		Connection con = null;
		int count = 0;
		log.debug("Add rooms");
		try {
			con = DBConnection.getConnection();
			log.debug("Connection Established");
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.addRooms);
			pstmt.setInt(1, room.getHotelId());
			pstmt.setString(2, room.getRoomNo());
			pstmt.setString(3, room.getRoomType());
			pstmt.setDouble(4, room.getRatePerNight());
			count = pstmt.executeUpdate();
			log.info("Rooms Addedd");
		} catch (SQLException e) {
			throw new HotelException("Unable to insert rooms " + e.getMessage());
		} catch (Exception e) {
			throw new HotelException("Unable to insert rooms " + e.getMessage());
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				throw new HotelException("Connection cannot be terminated"+e.getMessage());
			}
		}
		return count;
	}

	@Override
	public List<RoomBean> viewAllRooms(int hotelId) throws HotelException {
		Connection con = null;
		List<RoomBean> roomList = new ArrayList<RoomBean>();
		log.debug("View all rooms");
		try {
			con = DBConnection.getConnection();
			log.debug("Connection Established");
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.viewRooms);
			pstmt.setInt(1, hotelId);
			ResultSet r = pstmt.executeQuery();
			while (r.next()) {
				RoomBean rb = new RoomBean();
				rb.setRoomId(r.getInt("ROOM_ID"));
				rb.setHotelId(r.getInt("HOTEL_ID"));
				rb.setRoomNo(r.getString("ROOM_NO"));
				rb.setRoomType(r.getString("ROOM_TYPE"));
				rb.setRatePerNight(r.getDouble("PER_NIGHT_RATE"));
				rb.setAvailability(r.getString("AVAILABILITY"));
				roomList.add(rb);

			}
			log.debug("Rooms addedd successfully");
		} catch (SQLException e) {
			throw new HotelException("Unable to display the Room Details "+ e.getMessage());
		} catch (Exception e) {
			throw new HotelException("Unable to display the Room Details "+ e.getMessage());
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				throw new HotelException("Connection cannot be terminated"+e.getMessage());
			}
		}

		return roomList;
	}

	@Override
	public int updateRoom(RoomBean room) throws HotelException {
		log.debug("Update rooms");
		Connection con = null;
		int count = 0;
		try {
			con = DBConnection.getConnection();
			log.debug("Connection Established");
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.updateRoom);
			pstmt.setString(1, room.getRoomNo());
			pstmt.setString(2, room.getRoomType());
			pstmt.setDouble(3, room.getRatePerNight());
			pstmt.setString(4, room.getAvailability());
			pstmt.setInt(5, room.getHotelId());
			pstmt.setInt(6, room.getRoomId());
			count = pstmt.executeUpdate();

			
		} catch (SQLException e) {
			throw new HotelException("Failed to Update Rooms "+e.getMessage());
		} catch (Exception e) {
			throw new HotelException("Failed to Update Rooms "+e.getMessage());

		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				throw new HotelException("Connection cannot be terminated"+e.getMessage());
			}
		}
			return count;

	}

	@Override
	public int deleteRoom(int roomId) throws HotelException {
		Connection con = null;
		int count = 0;
		log.debug("delete rooms");
		try {
			con = DBConnection.getConnection();
			log.debug("Connection Established");
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.deleteRoom);
			pstmt.setInt(1, roomId);
			count = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			throw new HotelException("Failed to delete Room " + e.getMessage());
		} catch (Exception e) {
			throw new HotelException("Failed to delete Room " + e.getMessage());
		}

		finally {
			try {
				con.close();
			} catch (SQLException e) {
				throw new HotelException("Connection cannot be terminated"+e.getMessage());
			}
		}
		return count;
		
	}

	@Override
	public List<Booking> viewBookingList(int hotelId) throws HotelException {
		List<Booking> bookingList = new ArrayList<Booking>();
		Connection con = null;
		log.debug("View bookinglist");
		try {
			con = DBConnection.getConnection();
			log.debug("Connection Established");
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.getBookings);
			pstmt.setInt(1, hotelId);
			ResultSet r = pstmt.executeQuery();
			while (r.next()) {
				Booking b = new Booking();
				b.setBookingId(r.getInt("BOOKING_ID"));
				b.setHotelId(r.getInt("HOTEL_ID"));
				b.setRoomId(r.getInt("ROOM_ID"));
				b.setUserName(r.getString("USERNAME"));
				b.setBookedFrom(r.getDate("BOOKED_FROM"));
				b.setBookedTo(r.getDate("BOOKED_TO"));
				b.setAdultNo(r.getInt("NO_OF_ADULTS"));
				b.setChildrenNo(r.getInt("NO_OF_CHILDREN"));
				b.setAmount(r.getDouble("AMOUNT"));
				bookingList.add(b);
			}
		} catch (SQLException e) {
			throw new HotelException("Unable to display the BookingList "+ e.getMessage());
		} catch (Exception e) {
			throw new HotelException("Unable to display the BookingList "+ e.getMessage());
		}
		finally{
			try {
				con.close();
			} catch (SQLException e) {
				throw new HotelException("Connection cannot be terminated"+e.getMessage());
			}
		}

		return bookingList;
	}

	@Override
	public Set<User> viewGuestListByHotel(int hotelId)
			throws HotelException {
		log.debug("View guset list by hotel");
		Set<User> guestList = new HashSet<User>();
		Connection con = null;
		try {
			con = DBConnection.getConnection();
			log.debug("Connection Established");
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.getGuestListByHotel);
			pstmt.setInt(1, hotelId);
			ResultSet r = pstmt.executeQuery();
			while (r.next()) {
				User u = new User();
				u.setUserName(r.getString("USERNAME"));
				u.setEmail(r.getString("EMAILID"));
				u.setAddress(r.getString("ADDRESS"));
				u.setMobileNo(r.getString("MOBILENO"));
				guestList.add(u);
			
			}
		} catch (SQLException e) {
			throw new HotelException("Unable to display the GuestList "+ e.getMessage());
		} catch (Exception e) {
			throw new HotelException("Unable to display the GuestList "+ e.getMessage());
		}
		finally{
			try {
				con.close();
			} catch (SQLException e) {
				throw new HotelException("Connection cannot be terminated"+e.getMessage());
			}
		}
		return guestList;
	}

	
	

}
