package com.cg.hms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.hms.bean.User;
import com.cg.hms.exception.HotelException;
import com.cg.hms.util.DBConnection;

public class UserDaoImpl implements UserDao {

	@Override
	public User checkUser(String userName, String password)
			throws HotelException {
		Connection con=null;
		User user=null;
		try {
			con=DBConnection.getConnection();
			
				PreparedStatement pstmt=con.prepareStatement(QueryMapper.validateUser);
				pstmt.setString(1, userName);
				pstmt.setString(2, password);
				
				ResultSet r=pstmt.executeQuery();
				
				if(r.next())
				{
					String name=r.getString("username");
					String pass=r.getString("password");
					String role=r.getString("role");
					System.out.println(role);
					user=new User();
					user.setUserName(name);
					user.setPassword(pass);
					user.setRole(role);
					
				}
				
				
				
				
				
		} catch (SQLException e) {
			
		throw new HotelException("Invalid user name or password "+e.getMessage());
		
		} catch (Exception e) {
			//throw new HotelException("Database error 2 "+e.getMessage());
			
			throw new HotelException("Invalid user name or password "+e.getMessage());
		}
		
		finally{
			try {
				con.close();
			} catch (SQLException e) {
				throw new HotelException("Connection cannot be terminated"+e.getMessage());
			}
		}
				
		return user;
	}

	@Override
	public boolean registerUser(User u) throws HotelException {
		boolean flag=false;
		Connection con=null;
		try {
			con=DBConnection.getConnection();
			PreparedStatement pstmt=con.prepareStatement(QueryMapper.registerUser);
			pstmt.setString(1, u.getUserName());
			pstmt.setString(2, u.getPassword());
			pstmt.setString(3, u.getFullName());
			pstmt.setString(4, u.getMobileNo());
			pstmt.setString(5, u.getAddress());
			pstmt.setString(6, u.getEmail());
			int count=pstmt.executeUpdate();
			if(count>0)
			{
				
				flag=true;
			}
			else
			{
				
				flag=false;
			}
		} catch (SQLException e) {
			throw new HotelException("Unable to Register "+e.getMessage());
		} catch (Exception e) {
			throw new HotelException("Unable to Register "+e.getMessage());
		}
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				throw new HotelException("Connection cannot be terminated"+e.getMessage());
			}
		}
		return flag;
	}

	@Override
	public boolean registerEmployee(User u) throws HotelException {
		boolean flag=false;
		Connection con=null;
		try {
			con=DBConnection.getConnection();
			PreparedStatement pstmt=con.prepareStatement(QueryMapper.registerEmployee);
			pstmt.setString(1, u.getUserName());
			pstmt.setString(2, u.getPassword());
			pstmt.setString(3, u.getFullName());
			pstmt.setString(4, u.getMobileNo());
			pstmt.setString(5, u.getAddress());
			pstmt.setString(6, u.getEmail());
			int count=pstmt.executeUpdate();
			if(count>0)
			{
				
				flag=true;
			}
			else
			{
				
				flag=false;
			}
		} catch (SQLException e) {
			throw new HotelException("Unable to Register "+e.getMessage());
		} catch (Exception e) {
			throw new HotelException("Unable to Register "+e.getMessage());
		}
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				throw new HotelException("Connection cannot be terminated"+e.getMessage());
			}
		}
		return flag;
		
	}

}
