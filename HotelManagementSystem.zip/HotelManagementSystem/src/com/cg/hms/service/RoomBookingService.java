package com.cg.hms.service;

import java.util.List;

import com.cg.hms.bean.Booking;
import com.cg.hms.bean.Hotels;
import com.cg.hms.bean.RoomBean;
import com.cg.hms.exception.HotelException;

public interface RoomBookingService {
	
	public abstract List<Hotels> viewAllHotels() throws HotelException;
	public abstract List<RoomBean> viewAvailableRooms(int hotelId) throws HotelException;
	public int bookRoom(RoomBean r,String username,Booking b,String role) throws HotelException;
	public double getFare(int roomId) throws HotelException;
	public abstract Booking viewBookingStatus(int bookingId) throws HotelException;
	public abstract boolean validateBookingBean(Booking b) throws HotelException;
}
