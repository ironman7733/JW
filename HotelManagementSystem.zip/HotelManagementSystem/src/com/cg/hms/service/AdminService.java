package com.cg.hms.service;

import java.util.List;
import java.util.Set;

import com.cg.hms.bean.Booking;
import com.cg.hms.bean.Hotels;
import com.cg.hms.bean.RoomBean;
import com.cg.hms.bean.User;
import com.cg.hms.exception.HotelException;

public interface AdminService {
	public abstract int addHotel(Hotels h) throws HotelException;
	public abstract int updateHotel(Hotels h) throws HotelException;
	public abstract List<Hotels> viewAllHotels() throws HotelException;
	public abstract int deleteHotel(int hotelId) throws HotelException;
	public abstract List<Booking> viewGuestList() throws HotelException;
	public int addRooms(RoomBean room)throws HotelException;
	public abstract List<RoomBean> viewAllRooms(int hotelId) throws HotelException;
	public abstract int updateRoom(RoomBean room)throws HotelException;
	public abstract int deleteRoom(int roomId) throws HotelException;
	public abstract List<Booking> viewBookingList(int hotelId) throws HotelException;
	public abstract Set<User> viewGuestListByHotel(int hotelId) throws HotelException;
	public abstract  boolean validateHotelBean(Hotels hotel) throws HotelException;
	public abstract boolean validateRoomBean(RoomBean room) throws HotelException;
	public abstract boolean validateRoomBeanForUpdate(RoomBean room) throws HotelException;
}
