package com.cg.hms.service;

import java.util.regex.Pattern;

import com.cg.hms.bean.User;
import com.cg.hms.dao.UserDao;
import com.cg.hms.dao.UserDaoImpl;
import com.cg.hms.exception.HotelException;

public class UserServiceImpl implements UserService {
	
	UserDao dao=new UserDaoImpl();

	@Override
	public User checkUser(String userName, String password)
			throws HotelException {
		// TODO Auto-generated method stub
		
		return dao.checkUser(userName, password);
	}

	@Override
	public boolean registerUser(User u) throws HotelException {
		
		return dao.registerUser(u);
	}

	@Override
	public boolean validateUserInfo(User u) throws HotelException {
		boolean flag=true;
		if(!validateUserName(u.getUserName()))
			throw new HotelException("Invalid Format for User name");
		if(!validateUserPassword(u.getPassword()))
			throw new HotelException("Invalid Format for User password");
		if(!validateUserFullName(u.getFullName()))
			throw new HotelException("Invalid Format for Full name");
		if(!validateUserMobileNo(u.getMobileNo()))
			throw new HotelException("Invalid Format for Mobile No");
		if(!validateUserEmail(u.getEmail()))
			throw new HotelException("Invalid Format for email");
		if(!validateUserAddress(u.getAddress()))
			throw new HotelException("Invalid Format for Address");
		return flag;

		
	}
	
	
	
	public boolean validateUserName(String userName)
	{
		boolean b=Pattern.matches("[a-zA-Z]+", userName);
		return b;
	}
	
	public boolean validateUserPassword(String password)
	{
		boolean b=Pattern.matches("[a-zA-Z0-9]+",password);
		return b;
	}
	public boolean validateUserFullName(String fullName)
	{
		boolean b=Pattern.matches("[a-zA-Z\\s]+", fullName);
		return b;
	}
	public boolean validateUserMobileNo(String mobNo)
	{
		boolean b=Pattern.matches("[0-9]{10}", mobNo);
		return b;
	}
	public boolean validateUserEmail(String email)
	{
		boolean b=Pattern.matches("[a-z]{1}[a-z0-9]+@[a-z]+.[a-z]+", email);
		return b;
	}
	public boolean validateUserAddress(String address)
	{
		boolean b=Pattern.matches("[a-zA-Z\\s]+", address);
		return b;
	}

	@Override
	public boolean registerEmployee(User u) throws HotelException {
		// TODO Auto-generated method stub
		return dao.registerEmployee(u);
	}

}
