package com.cg.hms.service;

import com.cg.hms.bean.User;
import com.cg.hms.exception.HotelException;

public interface UserService {
	public User checkUser(String userName, String password) throws HotelException;
	public boolean registerUser(User u) throws HotelException;
	public boolean registerEmployee(User u) throws HotelException;
	public boolean validateUserInfo(User u)throws HotelException;
}
