package com.cg.hms.service;

import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;


import com.cg.hms.bean.Booking;
import com.cg.hms.bean.Hotels;
import com.cg.hms.bean.RoomBean;
import com.cg.hms.dao.RoomBookingDao;
import com.cg.hms.dao.RoomBookingImpl;
import com.cg.hms.exception.HotelException;

public class RoomBookingServiceImpl implements RoomBookingService {
	
	RoomBookingDao rbDao=new RoomBookingImpl();

	@Override
	public List<Hotels> viewAllHotels() throws HotelException {
		// TODO Auto-generated method stub
		return rbDao.viewAllHotels();
	}

	@Override
	public List<RoomBean> viewAvailableRooms(int hotelId) throws HotelException {
		// TODO Auto-generated method stub
		return rbDao.viewAvailableRooms(hotelId);
	}

	@Override
	public int bookRoom(RoomBean r, String username, Booking b,String role)
			throws HotelException {
		// TODO Auto-generated method stub
		double fare=getFare(r.getRoomId());
		int adults=b.getAdultNo();
		int children=b.getChildrenNo();
		int total=adults+children;
		Date start=b.getBookedFrom();
		Date end=b.getBookedTo();
		long difference=end.getTime()-start.getTime();
		long numberOfDays=TimeUnit.DAYS.convert(difference, TimeUnit.MILLISECONDS);
		double amountForSingleDay=total*fare;
		double amount=amountForSingleDay*numberOfDays;
		if(role.equalsIgnoreCase("employee"))
		{
			
			System.out.println("Great!! you got a discount");
			double discount=amount*0.1;
			double discountAmt=amount-discount;
			b.setAmount(discountAmt);
		}
		else
		b.setAmount(amount);
		return rbDao.bookRoom(r, username, b);
	}

	@Override
	public double getFare(int roomId) throws HotelException {
		// TODO Auto-generated method stub
		return rbDao.getFare(roomId);
	}

	@Override
	public Booking viewBookingStatus(int bookingId) throws HotelException {
		// TODO Auto-generated method stub
		return rbDao.viewBookingStatus(bookingId);
	}

	@Override
	public boolean validateBookingBean(Booking b) throws HotelException {
		// TODO Auto-generated method stub
		return false;
	}
	
	
	
	

}
