package com.cg.hms.service;

import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

import com.cg.hms.bean.Booking;
import com.cg.hms.bean.Hotels;
import com.cg.hms.bean.RoomBean;
import com.cg.hms.bean.User;
import com.cg.hms.dao.AdminDao;
import com.cg.hms.dao.AdminDaoImpl;
import com.cg.hms.exception.HotelException;

public class AdminServiceImpl implements AdminService {
	
	AdminDao dao=new AdminDaoImpl();

	@Override
	public int addHotel(Hotels h) throws HotelException {
		// TODO Auto-generated method stub
		return dao.addHotel(h);
	}

	@Override
	public int updateHotel(Hotels h) throws HotelException {
		
		return dao.updateHotel(h);
		
	}

	@Override
	public List<Hotels> viewAllHotels() throws HotelException {
		return dao.viewAllHotels();
	}

	@Override
	public int deleteHotel(int hotelId) throws HotelException {
		
		return dao.deleteHotel(hotelId);
		
	}

	@Override
	public List<Booking> viewGuestList() throws HotelException {
		
		return dao.viewGuestList();
	}

	@Override
	public int addRooms(RoomBean room) throws HotelException {
		
		return dao.addRooms(room);
	}

	@Override
	public List<RoomBean> viewAllRooms(int hotelId) throws HotelException {
		return dao.viewAllRooms(hotelId);
	}

	@Override
	public int updateRoom(RoomBean room) throws HotelException {
		return dao.updateRoom(room);
		
	}

	@Override
	public int deleteRoom(int roomId) throws HotelException {
		return dao.deleteRoom(roomId);
		
	}

	@Override
	public List<Booking> viewBookingList(int hotelId) throws HotelException {
		// TODO Auto-generated method stub
		return dao.viewBookingList(hotelId);
	}

	@Override
	public Set<User> viewGuestListByHotel(int hotelId) throws HotelException {
		// TODO Auto-generated method stub
		return dao.viewGuestListByHotel(hotelId);
	}

	@Override
	public boolean validateHotelBean(Hotels hotel) throws HotelException {
		boolean flag=true;
		if(!validateCity(hotel.getCity()))
		throw new HotelException("Invalid format for city");
		if(!validateAddress(hotel.getHotelAddress()))
			throw new HotelException("Invalid format for Address");
		if(!validateDescription(hotel.getHotelDescription()))
			throw new HotelException("Invalid format for Description");
		if(!validateEmail(hotel.getHotelEmail()))
			throw new HotelException("Invalid format for email");
		if(!validateHotelName(hotel.getHotelName()))
			throw new HotelException("Invalid format for Hotel Name");
		if(!validateRating(hotel.getHotelRating()))
			throw new HotelException("Invalid format for Rating");
		if(!validatePhone(hotel.getPhoneNo()))
			throw new HotelException("Invalid format for phone number");
		return flag;
	}
	
	public boolean validateCity(String city){
		boolean b=Pattern.matches("[a-zA-Z\\s]+", city);
		return b;
	}
	
	public boolean validateAddress(String address){
		boolean b=Pattern.matches("[a-zA-Z\\s]+", address);
		return b;
	}
	
	public boolean validateDescription(String description){
		boolean b=Pattern.matches("[a-zA-Z\\s]+", description);
		return b;
	}
	
	public boolean validateEmail(String email)
	{
		boolean b=Pattern.matches("[a-z]{1}[a-z0-9]+@[a-z]+.[a-z]+", email);
		return b;
	}
	
	public boolean validateHotelName(String hotelName)
	{
		 boolean b=Pattern.matches("[a-zA-Z\\s]+", hotelName);
		 return b;
	}
	public boolean validateRating(String rating){
		boolean b=Pattern.matches("[*]{1,5}", rating);
		return b;
		
	}
	
	public boolean validatePhone(String phone){
		boolean b=Pattern.matches("[0-9]{10}", phone);
		return b;
	}

	@Override
	public boolean validateRoomBean(RoomBean room) throws HotelException {
		boolean flag=true;
		if(!validateRoomNumber(room.getRoomNo()))
			throw new HotelException("Invalid Format for room number");
		if(!validateRoomType(room.getRoomType()))
			throw new HotelException("Invalid Format for room Type");
		return flag;
	}
	
	public boolean validateRoomNumber(String roomNumber)
	{
		boolean b=Pattern.matches("[a-zA-Z0-9]+", roomNumber);
		return b;
	}
	
	public boolean validateRoomType(String roomType)
	{
		boolean b=Pattern.matches("[A-Za-z]+", roomType);
		return b;
	}
	
	public boolean validateAvailability(String availability)
	{
		boolean b=Pattern.matches("[A-Za-z]+", availability);
		return b;
	}

	@Override
	public boolean validateRoomBeanForUpdate(RoomBean room)
			throws HotelException {
		boolean flag=true;
		if(!validateRoomNumber(room.getRoomNo()))
			throw new HotelException("Invalid Format for room number");
		if(!validateRoomType(room.getRoomType()))
			throw new HotelException("Invalid Format for room Type");
		if(!validateAvailability(room.getAvailability()))
			throw new HotelException("Invalid Format for room Availability");
		
		return flag;
	}
}
