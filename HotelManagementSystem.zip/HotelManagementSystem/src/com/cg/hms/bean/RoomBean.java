package com.cg.hms.bean;

public class RoomBean {
	
	private int roomId;
	private int hotelId;
	private String availability;
	private String roomNo;
	private String roomType;
	private double ratePerNight;
	
	
	public RoomBean() {
		super();
		// TODO Auto-generated constructor stub
	}


	public RoomBean(int roomId, int hotelId, String availability,
			String roomNo, String roomType, double ratePerNight) {
		super();
		this.roomId = roomId;
		this.hotelId = hotelId;
		this.availability = availability;
		this.roomNo = roomNo;
		this.roomType = roomType;
		this.ratePerNight = ratePerNight;
	}


	public int getRoomId() {
		return roomId;
	}


	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}


	public int getHotelId() {
		return hotelId;
	}


	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}


	public String getAvailability() {
		return availability;
	}


	public void setAvailability(String availability) {
		this.availability = availability;
	}


	public String getRoomNo() {
		return roomNo;
	}


	public void setRoomNo(String roomNo) {
		this.roomNo = roomNo;
	}


	public String getRoomType() {
		return roomType;
	}


	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}


	public double getRatePerNight() {
		return ratePerNight;
	}


	public void setRatePerNight(double ratePerNight) {
		this.ratePerNight = ratePerNight;
	}
	
	
	

}
