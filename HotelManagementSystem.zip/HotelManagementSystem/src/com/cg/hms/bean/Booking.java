package com.cg.hms.bean;

import java.util.Date;

public class Booking {
	
	private int bookingId;
	private int roomId;
	private String userName;
	private Date bookedFrom;
	private Date bookedTo;
	private int adultNo;
	private int childrenNo;
	private double amount;
	private int hotelId;
	
	
	public Booking(int bookingId, int roomId, String userName, Date bookedFrom,
			Date bookedTo, int adultNo, int childrenNo, double amount,
			int hotelId) {
		super();
		this.bookingId = bookingId;
		this.roomId = roomId;
		this.userName = userName;
		this.bookedFrom = bookedFrom;
		this.bookedTo = bookedTo;
		this.adultNo = adultNo;
		this.childrenNo = childrenNo;
		this.amount = amount;
		this.hotelId = hotelId;
	}



	public int getHotelId() {
		return hotelId;
	}



	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}



	public Booking() {
		super();
		// TODO Auto-generated constructor stub
	}





	public int getBookingId() {
		return bookingId;
	}



	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}



	public int getRoomId() {
		return roomId;
	}



	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}



	public String getUserName() {
		return userName;
	}



	public void setUserName(String userName) {
		this.userName = userName;
	}



	public Date getBookedFrom() {
		return bookedFrom;
	}



	public void setBookedFrom(Date bookedFrom) {
		this.bookedFrom = bookedFrom;
	}



	public Date getBookedTo() {
		return bookedTo;
	}



	public void setBookedTo(Date bookedTo) {
		this.bookedTo = bookedTo;
	}



	public int getAdultNo() {
		return adultNo;
	}



	public void setAdultNo(int adultNo) {
		this.adultNo = adultNo;
	}



	public int getChildrenNo() {
		return childrenNo;
	}



	public void setChildrenNo(int childrenNo) {
		this.childrenNo = childrenNo;
	}



	public double getAmount() {
		return amount;
	}



	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	
	
	
	
	
	

}
