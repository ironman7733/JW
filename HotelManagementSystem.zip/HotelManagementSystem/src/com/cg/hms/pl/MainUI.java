package com.cg.hms.pl;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.hms.bean.User;
import com.cg.hms.exception.HotelException;
import com.cg.hms.service.UserService;
import com.cg.hms.service.UserServiceImpl;

public class MainUI {
	Scanner scan;

	public static void main(String[] args) {

		MainUI m = new MainUI();
		m.start();

	}

	public void logIn() {

		UserService service = new UserServiceImpl();
		System.out.println("Enter user name");
		String user = scan.nextLine();
		System.out.println("Enter password");
		String pass = scan.nextLine();
		

		try {
			User u = null;

			u = service.checkUser(user, pass);
			if(u==null){
				System.out.println("Invalid user name or password");
			}
			else{
			String role = u.getRole();
			String username = u.getUserName();
		
		

			if (role.equalsIgnoreCase("admin")) {
				AdminConsole admin = new AdminConsole(username);
				admin.start();

			} else if (role.equalsIgnoreCase("user")||role.equalsIgnoreCase("employee")) {
				UserConsole users = new UserConsole(username,role);
				users.start();
			}
			}
		} catch (HotelException e) {
			System.out.println("Invalid user name or password");
		}

	}

	public void register() {
		boolean isValidate=false;
		UserService service = new UserServiceImpl();
		System.out.println("Enter user name");
		String username = scan.nextLine();
		System.out.println("Enter password");
		String password = scan.nextLine();
		System.out.println("Enter full name");
		String fullname = scan.nextLine();
		System.out.println("Enter mobile number");
		String mobile = scan.nextLine();
		System.out.println("Enter Address");
		String address = scan.nextLine();
		System.out.println("Enter email");
		String email = scan.nextLine();
		User u = new User();
		u.setUserName(username);
		u.setPassword(password);
		u.setFullName(fullname);
		u.setMobileNo(mobile);
		u.setAddress(address);
		u.setEmail(email);
		
		try {
			isValidate=service.validateUserInfo(u);
		} catch (HotelException e1) {
			System.out.println(e1.getMessage());
			System.out.println("Register Again!!");
		}
		
		try {
			if(isValidate){
			boolean flag = service.registerUser(u);
			if (flag == true) {
				System.out.println("Registered Successfully");
				System.out.println("Login with the following credentials");
				System.out.println("User name: " + username);
				System.out.println("Password: " + password);
			}
			else
			{
				System.out.println("Registration failed");
			}
			}
			
		} catch (HotelException e) {
			System.out.println(e.getMessage());
			
		}

	}
	
	public void registerEmployee(){
		
		boolean isValidate=false;
		UserService service = new UserServiceImpl();
		System.out.println("Enter user name");
		String username = scan.nextLine();
		System.out.println("Enter password");
		String password = scan.nextLine();
		System.out.println("Enter full name");
		String fullname = scan.nextLine();
		System.out.println("Enter mobile number");
		String mobile = scan.nextLine();
		System.out.println("Enter Address");
		String address = scan.nextLine();
		System.out.println("Enter email");
		String email = scan.nextLine();
		User u = new User();
		u.setUserName(username);
		u.setPassword(password);
		u.setFullName(fullname);
		u.setMobileNo(mobile);
		u.setAddress(address);
		u.setEmail(email);
		
		try {
			isValidate=service.validateUserInfo(u);
		} catch (HotelException e1) {
			System.out.println(e1.getMessage());
			System.out.println("Register Again!!");
		}
		
		try {
			if(isValidate){
			boolean flag = service.registerEmployee(u);
			if (flag == true) {
				System.out.println("Registered Successfully");
				System.out.println("Login with the following credentials");
				System.out.println("User name: " + username);
				System.out.println("Password: " + password);
			}
			else
			{
				System.out.println("Registration failed");
			}
			}
			
		} catch (HotelException e) {
			System.out.println(e.getMessage());
			
		}
		
		
		
	}

	public void start() {
		try{
		scan = new Scanner(System.in);
		while (true) {

			System.out.println("\n\n*****Hotel Management Application*****");
			System.out.println("Enter your choice");
			System.out.println("1.Login");
			System.out.println("2.Register As User");
			System.out.println("3.Register As Employee");
			System.out.println("4.Exit");
			int choice = scan.nextInt();
			scan.nextLine();
			switch (choice) {
			case 1:
				logIn();
				break;

			case 2:
				register();
				break;

			case 3:
				 registerEmployee();
				 break;
				 
			case 4:
				System.out.println("Thank you");
				System.exit(0);
				break;

			}

		}
		}catch(InputMismatchException i)
		{
			System.out.println("Enter valid choice ");
			scan.nextLine();
			start();
		}
	}

}
