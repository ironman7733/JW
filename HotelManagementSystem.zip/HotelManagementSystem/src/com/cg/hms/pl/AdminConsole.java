package com.cg.hms.pl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import com.cg.hms.bean.RoomBean;
import com.cg.hms.bean.Booking;
import com.cg.hms.bean.Hotels;
import com.cg.hms.bean.User;
import com.cg.hms.exception.HotelException;
import com.cg.hms.service.AdminService;
import com.cg.hms.service.AdminServiceImpl;

public class AdminConsole {
	
	private String currentUser;
	private AdminService serviceAdmin;
	private Scanner scan;
	public AdminConsole(String currentUser) {
		this.currentUser = currentUser;
	}
	
  public void start()
  {
	  scan=new Scanner(System.in);
	  serviceAdmin=new AdminServiceImpl();
	  System.out.println("Welcome "+currentUser);
	  
	  while(true)
	  {
		 
		  System.out.println("****Enter your choice*********");
		  System.out.println("1.Add Hotel");
		  System.out.println("2.Update Hotel");
		  System.out.println("3.View Hotels");
		  System.out.println("4.Delete Hotel");
		  System.out.println("5.View Guest List");
		  System.out.println("6.View Guest List of specific Hotel");
		  System.out.println("7.Add Rooms");
		  System.out.println("8.View Rooms");
		  System.out.println("9.Update Rooms");
		  System.out.println("10.Delete Rooms");
		  System.out.println("11.View Bookings of specific hotel");
		  System.out.println("12.Log out");
		 
		  int choice=scan.nextInt(); 
		  switch(choice)
		  {
		  case 1	:	addHotel();
		  				break;
		  				
		  case 2	:	updateHotel();
		  				break;
		  				
		  case 3	:	viewHotel();
		  				break;
		  				
		  case 4	:	deleteHotel();
		  				break;
		  
		  case 5	:	viewGuestList();
		  				break;
		  				
		  case 6	: 	viewGuestListByHotel();
		  				break;
		  				
		  case 7	:	addRooms();
		  				break;
		  				
		  case 8    : 	viewRooms();
		  				break;
		  				
		  case 9	:  	updateRooms();
		  				break;
		  				
		  case 10	: 	deleteRooms();
		  				break;
		  				
		  case 11	: 	viewBookingsByHotel();
		  				break;
		  				
		  case 12	:	System.out.println("Thank you!!");
		  				MainUI m=new MainUI();
		  				m.start();
		  				break;
		  
		  default	:	System.out.println("Invalid choice");
			  			start();
		  }
	
	  }
  }
	  
	 public void addHotel()
	 {
		 double avgRate=0;
		 scan.nextLine();
		 Hotels h=new Hotels();
		 boolean isValidate=false;
		System.out.println("Enter the Hotel name"); 
		String hotelName=scan.nextLine();
		System.out.println("Enter Hotel Address");
		String hotelAddress=scan.nextLine();
		System.out.println("Enter City");
		String city=scan.nextLine();
		System.out.println("Enter Description");
		String description=scan.nextLine();
		System.out.println("Enter email");
		String email=scan.nextLine();
		System.out.println("Enter Hotel Rating");
		String rating=scan.nextLine();
		System.out.println("Enter phone no");
		String phone=scan.nextLine();
		System.out.println("Enter Average rate per night");
		try{
		 avgRate=scan.nextDouble();
		h.setHotelName(hotelName);
		h.setCity(city);
		h.setHotelAddress(hotelAddress);
		h.setHotelDescription(description);
		h.setHotelEmail(email);
		h.setHotelRating(rating);
		h.setPhoneNo(phone);
		h.setAverageRate(avgRate);
		isValidate=serviceAdmin.validateHotelBean(h);
				
			if(isValidate)
			{
			int count=serviceAdmin.addHotel(h);
			if(count>0)
			{
				System.out.println("Hotel Added Successfully");
			}
			else
			{
				System.out.println("Failed to add Hotel");
			}
			}
		} catch (HotelException e) {
			System.out.println(e.getMessage());
		}catch(InputMismatchException i)
		{
			System.out.println("Invalid format for average rate");
			 scan.nextLine();
			 isValidate=false;
		}

	 }
	 
	 
	 
	 public void updateHotel()
	 {
		 double avgRate=0;
		 Hotels h=new Hotels();
		 boolean isValidate=false;
		 try{
		 System.out.println("Enter the Id of the Hotel to update");
		 int id=scan.nextInt();scan.nextLine();
		 System.out.println("***Details to Update***");
			 System.out.println("Enter the Hotel name"); 
			String hotelName=scan.nextLine();
			System.out.println("Enter Hotel Address");
			String hotelAddress=scan.nextLine();
			System.out.println("Enter City");
			String city=scan.nextLine();
			System.out.println("Enter Description");
			String description=scan.nextLine();
			System.out.println("Enter email");
			String email=scan.nextLine();
			System.out.println("Enter Hotel Rating");
			String rating=scan.nextLine();
			System.out.println("Enter phone no");
			String phone=scan.nextLine();
			System.out.println("Enter Average rate per night");
			
			 avgRate=scan.nextDouble();
			h.setHotelId(id);
			h.setHotelName(hotelName);
			h.setCity(city);
			h.setHotelAddress(hotelAddress);
			h.setHotelDescription(description);
			h.setHotelEmail(email);
			h.setHotelRating(rating);
			h.setPhoneNo(phone);
			h.setAverageRate(avgRate);
			
				isValidate=serviceAdmin.validateHotelBean(h);
			
			
			if(isValidate){
			
				int count=serviceAdmin.updateHotel(h);
				if(count>0)
				{
					System.out.println("Hotel Updated Successfully");
				}
				else
				{
					System.out.println("Failed to update Hotel");
				}
			} }catch (HotelException e) {
			System.out.println(e.getMessage());
			}catch(InputMismatchException i)
			{
				System.out.println("Pleas enter the Details in COrrect Format");
				 scan.nextLine();
				 isValidate=false;
			}
			}
	 
	 
	 
	 public void viewHotel()
	 {
		 System.out.println("**********************************************************************************************************************************************************************************************");
		 System.out.println("Hotel Id          Hotel Name           Hotel Address          Hotel City           Hotel Description           Hotel Email            Hotel Rating           Hotel phone         Hotel Rate   ");
		 System.out.println("**********************************************************************************************************************************************************************************************");
		 
		 try {
			List<Hotels> list=serviceAdmin.viewAllHotels();
			 
			 for (Hotels hotels : list) {
				 
			 System.out.println(hotels.getHotelId()+"                 "+hotels.getHotelName()+"               "+hotels.getHotelAddress()+"               "+hotels.getCity()+"               "+hotels.getHotelDescription()+"               "+hotels.getHotelEmail()+"               "+hotels.getHotelRating()+"               "+hotels.getPhoneNo()+"               "+hotels.getAverageRate());
				
			}
		} catch (HotelException e) {
			System.out.println(e.getMessage());
		}
	 }
	 
	 
	 
	 public void deleteHotel()
	 {
		 System.out.println("Enter the Hotel Id");
		 try{
		 int id=scan.nextInt();
		 
			int count=serviceAdmin.deleteHotel(id);
			if(count>0)
			{
				System.out.println("Hotel Deleted Successfully");
			}
			else
			{
				System.out.println("Failed to Delete Hotel");
			}
		} catch (HotelException e) {
			System.out.println(e.getMessage());
		}catch(InputMismatchException i){
			System.out.println("Invalid format for  Hotel Id");
			scan.nextLine();
		}
		 
		 
		 
		 
	 }
	 
	 public void viewGuestList()
	 {

			DateFormat d=new SimpleDateFormat("MM/dd/yyyy");
		 List<Booking> guestList=new ArrayList<Booking>();
		 try {
			guestList=serviceAdmin.viewGuestList();
			 if(guestList.isEmpty())
			 {
				 System.out.println("No guests");
			 }
			 else
			 {
				 System.out.println("************************************************************************************************************************************");
				 System.out.println("Booking Id    Hotel Id       Room Id        User name       Booked From      Booked Till      Adults     Children       Amount   ");
				 System.out.println("*************************************************************************************************************************************");
				for (Booking b : guestList) {
					String startDate=d.format(b.getBookedFrom());
					String endDate=d.format(b.getBookedTo());
			
			 System.out.println(b.getBookingId()+"         "+b.getHotelId()+"         "+b.getRoomId()+"         "+b.getUserName()+"         "+startDate+"         "+endDate+"         "+b.getAdultNo()+"         "+b.getChildrenNo()+"         "+b.getAmount());
				}
			 }
		} catch (HotelException e) {
			System.out.println(e.getMessage());
		}
	 }
	  
	 
	 
	 public void addRooms(){
		 boolean isValidate=false;
			System.out.println("Enter the Hotel Id");
			try{
			int rHotelId=scan.nextInt();scan.nextLine();
			
			System.out.println("Enter the room number");
			String roomNo=scan.nextLine();
			
			
			System.out.println("Enter room type");
			String roomType=scan.nextLine();
			
			
			System.out.println("Enter rate per night");
			
			double ratePerNight=scan.nextDouble();
			
			RoomBean room=new RoomBean();
			
			room.setHotelId(rHotelId);
			room.setRoomNo(roomNo);
			room.setRoomType(roomType);
			room.setRatePerNight(ratePerNight);
			
			
				isValidate=serviceAdmin.validateRoomBean(room);
			
			if(isValidate){
						
				int count=serviceAdmin.addRooms(room);
				if(count>0){
					System.out.println("Room Added Successfully");
				}
				else{
					System.out.println("Failed to add Room");
				}
			}
			} catch (HotelException e) {
				System.out.println(e.getMessage());
			}catch(InputMismatchException i)
			{
				System.out.println("Please Enter the Details in Correct format");
				scan.nextLine();
			}
		 
	 }
	 
	 public void viewRooms()
	 {
		 
		 try{
		 System.out.println("Enter the hotel Id");
		 int HotelId=scan.nextInt();
			List<RoomBean> list=serviceAdmin.viewAllRooms(HotelId);
			if(list.isEmpty())
			{
				System.out.println("No rooms Available");
			}
			else{
		 System.out.println("**********************************************************************************************************************");
		 System.out.println("Room Id         Hotel Id            Room No         Room Type        Availability      RatePerNight");
		 System.out.println("**********************************************************************************************************************");
		 
		 
		
			 
			 for ( RoomBean room : list) {
				 
			 System.out.println(room.getRoomId()+"                 "+room.getHotelId()+"               "+room.getRoomNo()+"               "+room.getRoomType()+"               "+room.getAvailability()+"               "+room.getRatePerNight());
				
			}
			}
		} catch (HotelException e) {
			System.out.println(e.getMessage());
		} catch(InputMismatchException i)
		 {
			System.out.println("Invalid format for Hotel Id");
			scan.nextLine();
		 }
		 
	 }
	 
	 
	 public  void updateRooms()
	 {
		 boolean isValidate=false;
		 RoomBean room=new RoomBean();
		 try{
		 System.out.println("Enter the Hotel Id to update the room");
		 int hid=scan.nextInt();
		 System.out.println("Enter the Room Id of the same hotel"); 
		 int rid=scan.nextInt();scan.nextLine();
		 System.out.println("***Details to Update***");
		 System.out.println("Enter the Room no");
		 String rNo=scan.nextLine();
		 System.out.println("Enter the Room Type");
		 String rtype=scan.nextLine();
		 System.out.println("Enter the availability of room");
		 String avail=scan.nextLine();
		 System.out.println("Enter the rate per night");
		 Double rate=scan.nextDouble();
		 room.setHotelId(hid);
		 room.setRoomId(rid);
		 room.setRoomNo(rNo);
		 room.setRoomType(rtype);
		 room.setAvailability(avail);
		 room.setRatePerNight(rate);
		
				isValidate=serviceAdmin.validateRoomBeanForUpdate(room);
			
		if(isValidate){
		 		int count=serviceAdmin.updateRoom(room);
		 		if(count>0)
		 		{
		 			System.out.println("Room Updated Successfully");
		 		}
		 		else
		 		{
		 			System.out.println("Failed to Update Room");
		 		}
		}else{System.out.println("Failed");}
		} catch (HotelException e) {
			System.out.println(e.getMessage());
			}catch(InputMismatchException i)
		 {
				System.out.println("Please Enter the details in the correct format");
				scan.nextLine();
				isValidate=false;
		 }
			}
	 
	 
	
	 public void deleteRooms()
	 {
		 try{
		 System.out.println("Enter the Room Id");
		 int id=scan.nextInt();
		
			int count=serviceAdmin.deleteRoom(id);
			if(count>0)
			{
				System.out.println("Room deleted Successfully");
			}
			else
			{
				System.out.println("Failed to delete Hotel");
			}
		} catch (HotelException e) {
			System.out.println(e.getMessage());
		}catch(InputMismatchException i)
		 {
			System.out.println("Invalid format for Room Id");
			scan.nextLine();
		 }
		 
		 
		 
		 
	 }
	 
	 public void viewBookingsByHotel()
	 {
		 viewHotel();
		 try{
		 System.out.println("Enter only the hotel Id in the list");
		 int id=scan.nextInt();
		 DateFormat d=new SimpleDateFormat("MM/dd/yyyy");
		 List<Booking> bookingList=new ArrayList<Booking>();
		 
			bookingList=serviceAdmin.viewBookingList(id);
			 if(bookingList.isEmpty())
			 {
				 System.out.println("No Bookings in this hotel");
			 }
			 else
			 {
				 System.out.println("*************************************************************************************************************************************");
				 System.out.println("Booking Id     Hotel Id      Room Id        User name      Booked From       Booked Till       Adults      Children      Amount   ");
				 System.out.println("*************************************************************************************************************************************");
				for (Booking b : bookingList) {
					String startDate=d.format(b.getBookedFrom());
					String endDate=d.format(b.getBookedTo());
			
			 System.out.println(b.getBookingId()+"         "+b.getHotelId()+"         "+b.getRoomId()+"         "+b.getUserName()+"         "+startDate+"         "+endDate+"         "+b.getAdultNo()+"         "+b.getChildrenNo()+"         "+b.getAmount());
				}
			 }
		} catch (HotelException e) {
			System.out.println(e.getMessage());
		}catch(InputMismatchException i)
		 {
			System.out.println("Invalid format for Hotel Id");
			scan.nextLine();
		 }
	 
		 
		 
	 }
	 
	 public void viewGuestListByHotel()
	 {
		 viewHotel();
		 
		 Set<User> list=new HashSet<User>();
		 System.out.println("Enter only the hotel Id in the list");
		 
		 
		 try {
			 int id=scan.nextInt();
				list=serviceAdmin.viewGuestListByHotel(id);
				 if(list.isEmpty())
				 {
					 System.out.println("No guests");
				 }
				 else
				 {
					 System.out.println("*********************************************************");
					 System.out.println("USERNAME    EMAIL ID       ADDRESS        MOBILE NO     ");
					 System.out.println("*********************************************************");
					for (User u : list) {
				
				 System.out.println(u.getUserName()+"         "+u.getEmail()+"         "+u.getAddress()+"         "+u.getMobileNo()+"");
					}
				 }
			} catch (HotelException e) {
				System.out.println(e.getMessage());
			}catch(InputMismatchException i)
		 	{
				System.out.println("Invalid format for Hotel Id");
				scan.nextLine();
		 	}
		 
	 }
	 
  }


