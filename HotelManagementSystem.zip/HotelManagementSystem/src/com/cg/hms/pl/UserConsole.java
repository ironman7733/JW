package com.cg.hms.pl;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.cg.hms.bean.Booking;
import com.cg.hms.bean.Hotels;
import com.cg.hms.bean.RoomBean;
import com.cg.hms.exception.HotelException;
import com.cg.hms.service.RoomBookingService;
import com.cg.hms.service.RoomBookingServiceImpl;

public class UserConsole {
	
	RoomBookingService rbService=new RoomBookingServiceImpl();
	private String currentUser;
	private String currentRole;
	Scanner scan=new Scanner(System.in);
	
	
	public UserConsole(String currentUser, String currentRole) {
		this.currentUser = currentUser;
		this.currentRole = currentRole;
	}

	public void start()
	{
		System.out.println("Welcome "+currentUser);
		while(true){
		System.out.println("\n\nEnter your choice");
		System.out.println("1.Search for Hotel Rooms");
		System.out.println("2.Book Rooms");
		System.out.println("3.View Booking Status");
		System.out.println("4.Log out");
		
		
		int choice=scan.nextInt();scan.nextLine();
		switch(choice)
		{
		
		case 1	:	searchRooms();
					break;
					
					
		case 2	:	bookRooms();
					break;
					
					
		case 3	:	viewBookingStatus();
					break;
					
		case 4	:	System.out.println("Thank you!!");
					MainUI m=new MainUI();
					m.start();
					break;
		}
		
		}
	}
	
	public void searchRooms()
	{
		
		 
		 try {
				List<Hotels> list=new ArrayList<Hotels>();
				list=rbService.viewAllHotels();
				 if(list.isEmpty())
				 {
					 System.out.println("No Hotels Available ");
				 }
				 else
				 {
					 System.out.println("*********************************************************************************************");
					 System.out.println("Hotel Id          Hotel Name           Hotel Address          Hotel City          Hotel Rate   ");
					 System.out.println("*********************************************************************************************");
				 for (Hotels hotels : list) {
					 
				 System.out.println(hotels.getHotelId()+"                 "+hotels.getHotelName()+"               "+hotels.getHotelAddress()+"               "+hotels.getCity()+"               "+hotels.getAverageRate());
					
				}
			
		 System.out.println("\n\nEnter only the Hotel Id in the above list to View Available Rooms ");
		 
		 int hotelId=scan.nextInt();
		 
		 List<RoomBean> roomList=new ArrayList<RoomBean>();
		
		 
			roomList=rbService.viewAvailableRooms(hotelId);
			 if(roomList.isEmpty())
			 {
				 System.out.println("No rooms available ");
			 }else{
			System.out.println("***********************************************************************************");
			 System.out.println(" Hotel Id          Room Id          Room Number            Room Type          Rate per Night         ");
			 System.out.println("**********************************************************************************");
			 for (RoomBean roomBean : roomList) {
					System.out.println(roomBean.getHotelId()+"          "+roomBean.getRoomId()+"                   "+roomBean.getRoomNo()+"                   "+roomBean.getRoomType()+"                   "+roomBean.getRatePerNight());
				}
			 }
				 }
		} catch (HotelException e) {
			System.out.println(e.getMessage());
		}catch(InputMismatchException i)
		 {
			System.out.println("Invalid format for Hotel Id");
			scan.nextLine();
		 }
		
		 }
	
	
	
	public void bookRooms()
	{
		Booking book=new Booking();
		RoomBean r=new RoomBean();
		try{
		System.out.println("\n\nEnter the Hotel Id :");
		int hotelId=scan.nextInt();
		System.out.println("Enter the Room Id");
		int roomId=scan.nextInt();scan.nextLine();
		System.out.println("Book rooms from Date? (mm/dd/yyyy)");
		String bookedFrom=scan.nextLine();
		//String [] fromDate=bookedFrom.split("-");
		System.out.println("Book rooms till Date? (mm/dd/yyyy)");
		String bookedTill=scan.nextLine();
		/*DateTimeFormatter formatter=DateTimeFormatter.ofPattern("MM/dd/yyyy");
		Date startDate=Date.parse(bookedFrom,formatter);
		LocalDate endDate=LocalDate.parse(bookedFrom,formatter);
		//	System.out.println(startDate);
		//	System.out.println(endDate);
		 
*/		
		
		System.out.println("Enter the number of adults ");
		int adults=scan.nextInt();
		System.out.println("Enter the number of children ");
		int children=scan.nextInt();scan.nextLine();
		DateFormat d=new SimpleDateFormat("MM/dd/yyyy");
		System.out.println("Do you want to book this rooms.Are you sure?[Y/N]");
		String check=scan.nextLine();
		if(check.equalsIgnoreCase("y"))
		{
		
			try {
				Date startDate = d.parse(bookedFrom);
				Date endDate=d.parse(bookedTill);
				
				r.setHotelId(hotelId);
				r.setRoomId(roomId);
				book.setHotelId(hotelId);
				book.setUserName(currentUser);
				book.setBookedFrom(startDate);
				book.setBookedTo(endDate);
				book.setAdultNo(adults);
				book.setChildrenNo(children);
				int bookingId=rbService.bookRoom(r, currentUser, book,currentRole);
				if(bookingId>0)
				System.out.println("Your Booking Id is "+bookingId);
				else
					System.out.println("Invalid Hotel Id and Room Id");
				
			} catch (ParseException e) {
				System.out.println("Enter the date in required format "+e.getMessage());
				
			} catch (HotelException e) {
				System.out.println("Unable to book rooms "+e.getMessage());
			}
		
		}
		else
		{
			System.out.println("Booking cancelled");
		}
		}catch(InputMismatchException i)
		{
			System.out.println("Please enter details in correct format");
			scan.nextLine();
		}
	}
	
	
	public void viewBookingStatus()
	{
		Booking b=null;
		try{
		System.out.println("Enter your Booking Id");
		int bookingId=scan.nextInt();
		
			b=rbService.viewBookingStatus(bookingId);
			
			if(b==null)
			{
				System.out.println("Invalid Booking Id");
			}
			else
			{
				DateFormat d=new SimpleDateFormat("MM/dd/yyyy");
				String startDate=d.format(b.getBookedFrom());
				String endDate=d.format(b.getBookedTo());
				 System.out.println("***********************************************************************************************************************************************************");
				 System.out.println("Booking Id         Hotel Id          Room Id           User name          Booked From         Booked Till         Adults         Children         Amount   ");
				 System.out.println("***********************************************************************************************************************************************************");
				 System.out.println(b.getBookingId()+"         "+b.getHotelId()+"         "+b.getRoomId()+"         "+b.getUserName()+"         "+startDate+"         "+endDate+"         "+b.getAdultNo()+"         "+b.getChildrenNo()+"         "+b.getAmount());
			}
		} catch (HotelException e) {
			System.out.println("Unable to view Booking Status "+e.getMessage());
		}catch(InputMismatchException i)
		{
			System.out.println("Invalid format for BookingId");
			scan.nextLine();
		}
		
		
	}

}
