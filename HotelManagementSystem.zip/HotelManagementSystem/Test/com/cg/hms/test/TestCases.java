package com.cg.hms.test;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Test;

import com.cg.hms.bean.Booking;
import com.cg.hms.bean.Hotels;
import com.cg.hms.bean.RoomBean;
import com.cg.hms.bean.User;
import com.cg.hms.dao.AdminDaoImpl;
import com.cg.hms.dao.RoomBookingImpl;
import com.cg.hms.dao.UserDaoImpl;
import com.cg.hms.exception.HotelException;

import static org.junit.Assert.*;

public class TestCases {
	
	
	@Test
	public void testLogin(){
		
	UserDaoImpl u=new UserDaoImpl();
	String userName="Nithish";
	String password="nidhan";
	try {
		User uObject=u.checkUser(userName, password);
		assertNotNull(uObject);
	} catch (HotelException e) {
		System.out.println(e.getMessage());
	}
	
	}
	
	
	@Test
	public void testBookRooms()
	{
		RoomBean r=new RoomBean();
		Booking b=new Booking();
		RoomBookingImpl dao=new RoomBookingImpl();
		DateFormat d=new SimpleDateFormat("MM/dd/yyyy");
		String bookedFrom="02/03/2018";
		String bookedTill="02/04/2018";

		String userName="Venkat";
		try {
			Date startDate = d.parse(bookedFrom);
			Date endDate=d.parse(bookedTill);
			r.setRoomId(1021);
			r.setHotelId(1040);
			b.setHotelId(1040);
			b.setRoomId(1021);
			b.setBookedFrom(startDate);
			b.setBookedTo(endDate);
			b.setAdultNo(1);
			b.setChildrenNo(1);
			b.setAmount(dao.getFare(1021));
			int count=dao.bookRoom(r, userName, b);
			assertNotNull(count);
		} catch (ParseException e) {
			System.out.println("Enter date in correct format");
		} catch (HotelException e) {
			System.out.println(e.getMessage());
		}
				
	}
	
	@Test
	public void testUpdateHotel(){
		AdminDaoImpl dao=new AdminDaoImpl();
		Hotels h=new Hotels();
		h.setHotelId(1040);
		h.setHotelName("Zuri");
		h.setHotelAddress("whitefield");
		h.setCity("bangalore");
		h.setHotelDescription("good");
		h.setPhoneNo("9876565432");
		h.setHotelEmail("zuri@gmail.com");
		h.setHotelRating("*****");
		h.setAverageRate(234);
		try {
			int count=dao.updateHotel(h);
			assertNotNull(count);
		} catch (HotelException e) {
			System.out.println(e.getMessage());
		}
		
		
		
	}

}
