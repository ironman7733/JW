CREATE TABLE hotels (
hotelId number(4) PRIMARY KEY,
city varchar2(30),
hotelName varchar2(30),
hotelAddress varchar2(30),
hotelDescription varchar2(100),
avgRatePerNight  number(20,10),
phoneNo number(10),
hotelRating varchar2(10),
hotelEmail varchar2(40)
);





create table rooms(
   room_id number(4) primary key,
   room_no varchar2(3),
   room_type varchar2(20),
   per_night_rate number(20,10),
   availability varchar2(5),
   hotel_id number references hotels(hotelId)
   on delete cascade
    );
  
  
CREATE TABLE BookingDetails(
booking_id number(10) primary key, 
username varchar2(50),
booked_from date, 
booked_to date, 
no_of_adults number, 
no_of_children number, 
amount number(7,2),
room_id number(10) references ROOMS(room_id) on delete cascade,
hotel_id number references hotels(hotelId)
on delete cascade
);

CREATE TABLE users(
username varchar2(25) primary key,
password varchar2(25),
fullname varchar2(25),
role varchar2(20),
mobileNo varchar2(10),
address varchar2(50),
emailId varchar2(30)
);

create sequence hId start with 1000;
create sequence  bookingId start with 1000;