 create table product_tbl(
 productCode number primary key,
 productName varchar2(35),
 price number(10,2),
 totalQuantity number,
 productDate date);



 create table transaction_tbl(
 tId number primary key,
 productCode number references product_tbl(productCode),
 tDate Date,
 description varchar2(55),
 productPurchased number);


SQL> insert into product_tbl values (1,'soap',15,55,'01-jan-2018');

1 row created.

SQL> insert into product_tbl values (2,'tv',15000,35,'15-jan-2018');

1 row created.

SQL> insert into product_tbl values (3,'mobile',10000,25,'21-jan-2018');

1 row created.

SQL> commit;

Commit complete.

SQL> insert into transaction_tbl values(11,1,'01-feb-2018','good soap',5);

1 row created.

SQL> insert into transaction_tbl values(12,1,'02-feb-2018','good soap',3);

1 row created.

SQL> insert into transaction_tbl values(13,1,'03-feb-2018','good soap',1);

1 row created.

SQL> insert into transaction_tbl values(14,2,'04-feb-2018','good tv',3);

1 row created.

SQL> insert into transaction_tbl values(15,2,'05-feb-2018','good tv',2);

1 row created.

SQL> insert into transaction_tbl values(16,2,'06-feb-2018','good tv',1);

1 row created.

SQL> insert into transaction_tbl values(17,3,'07-feb-2018','good mobile',3);

1 row created.

SQL> insert into transaction_tbl values(18,3,'08-feb-2018','good mobile',3);

1 row created.

SQL> commit;

Commit complete.

SQL> commit;


