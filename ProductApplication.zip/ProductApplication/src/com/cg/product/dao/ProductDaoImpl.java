package com.cg.product.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.product.bean.ProductBean;
import com.cg.product.bean.TransactionBean;
import com.cg.product.exception.ProductException;

@Repository
@Transactional()
public class ProductDaoImpl implements IProductDao {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public List<TransactionBean> getTransactions(int prodId) throws ProductException {
        List<TransactionBean> list = null;
        try {
            TypedQuery<TransactionBean> query = entityManager.createQuery(
                    "SELECT d FROM TransactionBean d where productCode=?",
                    TransactionBean.class);
            query.setParameter(1, prodId);
            list = new ArrayList<TransactionBean>();
            list = query.getResultList();
        } catch (Exception e) {
            throw new ProductException("PRODUCT ID NOT FOUND");
        }
        return list;
    }

    @Override
    public ProductBean getProductName(int prodId) throws ProductException {
        ProductBean product= null;
        try 
        {
            product=entityManager.find(ProductBean.class,prodId);
            
        } catch (Exception e)
        {
            throw new ProductException("PRODUCT ID NOT FOUND");
        }
        return product;
    }

}
