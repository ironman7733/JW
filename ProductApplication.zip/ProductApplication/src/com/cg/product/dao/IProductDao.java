package com.cg.product.dao;

import java.util.List;

import com.cg.product.bean.ProductBean;
import com.cg.product.bean.TransactionBean;
import com.cg.product.exception.ProductException;


public interface IProductDao {
public List<TransactionBean> getTransactions(int prodId) throws ProductException;
public ProductBean getProductName(int prodId) throws ProductException;
}
