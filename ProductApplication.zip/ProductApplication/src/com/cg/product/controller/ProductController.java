package com.cg.product.controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;





import com.cg.product.bean.ProductBean;
import com.cg.product.bean.TransactionBean;
import com.cg.product.exception.ProductException;
import com.cg.product.service.IProductService;

@Controller
public class ProductController {
    @Autowired
    IProductService service;

    public IProductService getService() {
        return service;
    }

    public void setService(IProductService service) {
        this.service = service;
    }

    @RequestMapping("/showHomePage")
    public ModelAndView showHomePage() {
        ProductBean product = new ProductBean();
        return new ModelAndView("index", "product", product);
    }

    @RequestMapping("/fetch")
    public ModelAndView showFetch(
            @ModelAttribute("product") ProductBean product) {
        ModelAndView mv = new ModelAndView();
        
            try
            {
                ProductBean prod= new ProductBean();
                prod=service.getProductName(product.getProductCode());
               
                if(prod!=null)
                {
                    mv.setViewName("show");
                    mv.addObject("name", prod.getProductName());
                    mv.addObject("prodId", product.getProductCode());
                    List<TransactionBean> list = service.getTransactions(product.getProductCode());
                
                
            
                if (list.isEmpty()) {
                    String msg = "No transactions found";
                    mv.setViewName("myError");
                    mv.addObject("msg", msg);
                } else {
                    mv.setViewName("show");
                    mv.addObject("list", list);
              
                }
            }
                else
                {
                    String msg = "ID NOT VALID";
                    mv.setViewName("myError");
                    mv.addObject("msg", msg);
                }
            } 
            
            catch (ProductException e)
            {
                mv.setViewName("myError");
                mv.addObject("msg", e.getMessage());
            }
         
        return mv;
    }
}
