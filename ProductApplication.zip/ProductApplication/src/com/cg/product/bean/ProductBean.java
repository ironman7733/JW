package com.cg.product.bean;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="product_tbl")
public class ProductBean {

	@Id
	private int productCode;
	
	@NotEmpty(message="Please Enter Product Name")
	@Pattern(regexp = "^[a-zA-Z]+$", message = "Productname must contain only alphabets")
	
	private String productName;
	private int price;
	private int totalQuantity;
	private Date productDate;
	public ProductBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ProductBean(int productCode, String productName, int price,
			int totalQuantity, Date productDate) {
		super();
		this.productCode = productCode;
		this.productName = productName;
		this.price = price;
		this.totalQuantity = totalQuantity;
		this.productDate = productDate;
	}
	public int getProductCode() {
		return productCode;
	}
	public void setProductCode(int productCode) {
		this.productCode = productCode;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getTotalQuantity() {
		return totalQuantity;
	}
	public void setTotalQuantity(int totalQuantity) {
		this.totalQuantity = totalQuantity;
	}
	public Date getProductDate() {
		return productDate;
	}
	public void setProductDate(Date productDate) {
		this.productDate = productDate;
	}
	
	
	
}
