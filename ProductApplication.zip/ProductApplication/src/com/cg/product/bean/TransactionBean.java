package com.cg.product.bean;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="transaction_tbl")
public class TransactionBean {

	@Id
	private int tId;
	
	private int productcode;
	private Date tDate;
	private String description;
	private int productPurchased;
	
	public TransactionBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TransactionBean(int tId, int productcode, Date tDate,
			String description, int productPurchased) {
		super();
		this.tId = tId;
		this.productcode = productcode;
		this.tDate = tDate;
		this.description = description;
		this.productPurchased = productPurchased;
	}

	public int gettId() {
		return tId;
	}

	public void settId(int tId) {
		this.tId = tId;
	}

	public int getProductcode() {
		return productcode;
	}

	public void setProductcode(int productcode) {
		this.productcode = productcode;
	}

	public Date gettDate() {
		return tDate;
	}

	public void settDate(Date tDate) {
		this.tDate = tDate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getProductPurchased() {
		return productPurchased;
	}

	public void setProductPurchased(int productPurchased) {
		this.productPurchased = productPurchased;
	}
	
	
	
}
