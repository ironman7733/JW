package com.cg.product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.product.bean.ProductBean;
import com.cg.product.bean.TransactionBean;
import com.cg.product.dao.IProductDao;
import com.cg.product.exception.ProductException;
@Service
public class ProductServiceImpl implements IProductService{
    @Autowired
    IProductDao dao;

    public IProductDao getDao() {
        return dao;
    }

    public void setDao(IProductDao dao) {
        this.dao = dao;
    }

    @Override
    public List<TransactionBean> getTransactions(int prodId) throws ProductException {
        return dao.getTransactions(prodId);

    }

    @Override
    public ProductBean getProductName(int prodId) throws ProductException {
        return dao.getProductName(prodId);
    }
    
}
