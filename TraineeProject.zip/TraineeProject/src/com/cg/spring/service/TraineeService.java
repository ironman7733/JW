package com.cg.spring.service;

import java.util.ArrayList;

import com.cg.spring.entities.Trainee;

public interface TraineeService {

	int addTrainee(Trainee trainee);

	int deleteTraine(Trainee id);

	Trainee fetchRecord(Trainee id);

	void updateRecord(Trainee record);

	Trainee singleRecord(Trainee id);

	ArrayList<Trainee> showAll();
}
