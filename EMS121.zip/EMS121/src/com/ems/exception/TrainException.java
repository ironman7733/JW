package com.ems.exception;

public class TrainException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6194990504864111975L;

	public TrainException(String message)
	{
		super(message);
	}
}
