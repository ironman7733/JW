package com.ems.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ems.bean.TrainBean;
import com.ems.exception.TrainException;
import com.ems.util.DbConnection;

public class TrainDaoImpl implements ITrainDao{

	@Override
	public List<TrainBean> viewAllTrains() throws TrainException {
		List<TrainBean> list = new ArrayList<TrainBean>();
		
		Connection con = DbConnection.getConnection(); 
		
		try {
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.SELECT_QUERY);
			
			ResultSet rst = pstmt.executeQuery();
			
			while(rst.next())
			{
				TrainBean bean = new TrainBean();
				bean.setTrainId(rst.getString("TrainId"));
				bean.setTrainName(rst.getString("TrainName"));
				bean.setTrainDest(rst.getString("Destination"));
				bean.setTrainDept(rst.getDate("DepartDate").toLocalDate());
				bean.setTrainSeats(rst.getInt("seats"));
				bean.setTrainFare(rst.getDouble("fare"));
				list.add(bean);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return (list);
	}

	@Override
	public TrainBean getTrainDetails(String id) throws TrainException {
		TrainBean bean = null;
		Connection con = DbConnection.getConnection();
		try {
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.SELECT_BY_ID);
			pstmt.setString(1, id);
			ResultSet rst = pstmt.executeQuery();
			if(rst.next())
			{
				bean = new TrainBean();
				bean.setTrainId(rst.getString("TrainId"));
				bean.setTrainName(rst.getString("TrainName"));
				bean.setTrainDest(rst.getString("Destination"));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bean;
	}

	@Override
	public boolean bookTrain(String id, int sets) throws TrainException {
		// TODO Auto-generated method stub
		return false;
	}

}
