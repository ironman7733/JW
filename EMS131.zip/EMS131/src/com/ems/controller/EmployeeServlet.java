package com.ems.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ems.bean.TrainBean;
import com.ems.exception.TrainException;
import com.ems.service.ITrainService;
import com.ems.service.TrainServiceImpl;

/**
 * Servlet implementation class EmployeeServlet
 */
@WebServlet("*.obj")
public class EmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		//PrintWriter out = response.getWriter();
		
		String path = request.getServletPath().trim();
		
		//String message = "";
		String target = "";
		ITrainService service = new TrainServiceImpl();
		
		switch(path)
		{
		
		case "/show.obj" :
			String id = request.getParameter("tid");
			try 
			{
				TrainBean bean = service.getTrainDetails(id);
				if(bean!=null)
				{
					request.setAttribute("bean", bean);
					target = "showTrainInfo.jsp";
				}
				else
				{
					request.setAttribute("message", "ID NOT FOUND");
					target = "error.jsp";
				}
			} 
			catch (TrainException e1) 
			{
				request.setAttribute("message", "Exception = "+e1.getMessage());
			}
			break;
		case "/add.obj" : 
			target = "add.html"; 
			//message = "ADD SUCCESS";
			break;
		case "/update.obj" : 
			target = "update.html";
			//message = "UPDATE SUCCESS";
			break;
		case "/delete.obj" : 
			target = "delete.html";
			//message = "DELETE SUCCESS";
			break;
		case "/view.obj" : 
			try
			{
				List<TrainBean> list =  service.viewAllTrains();
						if(list.isEmpty())
						{
							target ="error.html";
						}
						else
						{
							request.setAttribute("list",list);
							//target="/DisplayTrainDetail";
							target="viewAllTrainDetails.jsp";
						}
	
		
						//RequestDispatcher rd = request.getRequestDispatcher(target);
						//rd.forward(request,response);
			}
			catch(TrainException e)
			{
				target = "error1.html";
			}
			break;
			case "/home.obj" :
				target = "index.html";
				//message = "Index File";
			break;
		}
		RequestDispatcher rd = request.getRequestDispatcher(target);
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
