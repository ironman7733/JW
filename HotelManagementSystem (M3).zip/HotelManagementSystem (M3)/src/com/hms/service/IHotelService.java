package com.hms.service;

import java.util.List;
import com.hms.bean.HotelBean;
import com.hms.exception.HotelException;
public interface IHotelService 
{
	public List<HotelBean> viewAllHotels() throws HotelException;
}
