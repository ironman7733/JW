package com.hms.service;

import java.util.List;
import com.hms.bean.HotelBean;
import com.hms.dao.HotelDaoImpl;
import com.hms.dao.IHotelDao;
import com.hms.exception.HotelException;

public class HotelServiceImpl implements IHotelService 
{
	
	
	private IHotelDao dao = new HotelDaoImpl();

	@Override
	public List<HotelBean> viewAllHotels() throws HotelException 
	{
		return dao.viewAllHotels();
		
		
	}

}
