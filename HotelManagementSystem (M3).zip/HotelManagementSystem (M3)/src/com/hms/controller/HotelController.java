package com.hms.controller;



import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hms.bean.HotelBean;
import com.hms.exception.HotelException;
import com.hms.service.HotelServiceImpl;
import com.hms.service.IHotelService;

/**
 * Servlet implementation class HotelController
 */
@WebServlet("*.obj")
public class HotelController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HotelController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = request.getServletPath().trim();
		String target = "";
		IHotelService service = new HotelServiceImpl();
		switch(path)
		{
		case "/view.obj" : 
			try
			{
				List<HotelBean> list =  service.viewAllHotels();
						if(list.isEmpty())
						{
							target ="error.jsp";
						}
						else
						{
							request.setAttribute("list",list);
							target="viewAllHotels.jsp";
						}
			}
			catch(HotelException e)
			{
				target = "errorexception.html";
			}
			break;
		}
		RequestDispatcher rd = request.getRequestDispatcher(target);
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
