package com.hms.exception;

public class HotelException extends Exception
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3969444649443701318L;

	public HotelException(String message)
	{
		super(message);
	}
}
