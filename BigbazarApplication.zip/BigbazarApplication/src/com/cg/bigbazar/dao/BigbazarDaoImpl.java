package com.cg.bigbazar.dao;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;
import com.cg.bigbazar.beans.Products;
import com.cg.bigbazar.beans.Transaction;

@Repository
@Transactional
public class BigbazarDaoImpl implements IBigbazarDao
{

	@PersistenceContext
	EntityManager em;
	@Override
	public Products getProductById(int productId) 
	{
		Products products = em.find(Products.class, productId);
		return products;
	}

	@Override
	public List<Transaction> getTransList(int productId) 
	{
		String qry = "select t from Transaction t where t.productId = " + productId;
		List<Transaction> transList = em.createQuery(qry, Transaction.class).getResultList();
		return transList;
	}

}
