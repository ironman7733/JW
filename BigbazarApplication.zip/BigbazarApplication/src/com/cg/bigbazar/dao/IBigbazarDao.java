package com.cg.bigbazar.dao;

import java.util.List;
import com.cg.bigbazar.beans.Products;
import com.cg.bigbazar.beans.Transaction;


public interface IBigbazarDao 
{

	public Products getProductById(int productId);
	public List<Transaction> getTransList(int productId);
}
