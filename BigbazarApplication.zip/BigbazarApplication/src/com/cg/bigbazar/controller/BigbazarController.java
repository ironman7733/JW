package com.cg.bigbazar.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.bigbazar.beans.Products;
import com.cg.bigbazar.beans.Transaction;
import com.cg.bigbazar.service.IBigbazarService;

@Controller
public class BigbazarController 
{

	@Autowired
	IBigbazarService service;

	public IBigbazarService getService() {
		return service;
	}

	public void setService(IBigbazarService service) {
		this.service = service;
	}
	
	@RequestMapping(value = "/showHomePage")
	public ModelAndView showHomePage() {
		Products products = new Products();

		ModelAndView mv = new ModelAndView("index", "products", products);

		return mv;
	}

	@RequestMapping(value = "/searchtrans")
	public ModelAndView searchTrans(
			@ModelAttribute("products") Products products) {
		
		int productId = products.getProductId();
		
		ModelAndView mv = null;
		
		Products products2 = service.getProductById(productId);
		if (products2==null) {
			
			mv = new ModelAndView("index");
			mv.addObject("msg", "Product does not exits");
			
		}else{
			List<Transaction> transList = service.getTransList(productId);
			if (transList.isEmpty()) {
				mv = new ModelAndView("display");
				mv.addObject("product", products2);
				mv.addObject("isThere", false);
			}else{
				mv = new ModelAndView("display");
				mv.addObject("product", products2);
				mv.addObject("transList", transList);
				mv.addObject("isThere", true);
			}
			
		}
		
		return mv;
		
	}
	
}
