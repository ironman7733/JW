package com.cg.bigbazar.service;

import java.util.List;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bigbazar.beans.Products;
import com.cg.bigbazar.beans.Transaction;
import com.cg.bigbazar.dao.IBigbazarDao;

@Service
@Transactional
public class BigbazarServiceImpl implements IBigbazarService
{

	@Autowired
	IBigbazarDao dao;
	
	
	public IBigbazarDao getDao() {
		return dao;
	}

	public void setDao(IBigbazarDao dao) {
		this.dao = dao;
	}

	@Override
	public Products getProductById(int productId) 
	{
		return dao.getProductById(productId);
	}

	@Override
	public List<Transaction> getTransList(int productId) 
	{
		return dao.getTransList(productId);
	}

}
