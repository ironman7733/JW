package com.cg.bigbazar.service;

import java.util.List;
import com.cg.bigbazar.beans.Products;
import com.cg.bigbazar.beans.Transaction;

public interface IBigbazarService 
{

	public Products getProductById(int productId);
	public List<Transaction> getTransList(int productId);
}
