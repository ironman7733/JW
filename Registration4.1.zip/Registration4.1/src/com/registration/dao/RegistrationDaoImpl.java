package com.registration.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.registration.dto.RegistrationDto;
import com.registration.exception.RegistrationException;
import com.registration.util.DbConnection;

public class RegistrationDaoImpl implements IRegistrationDao {
	
	
	
	@Override
	public int addUser(RegistrationDto User) throws RegistrationException {
		int count=0;
		Connection con=DbConnection.getConnection();
		try 
		{
			PreparedStatement pstmt=con.prepareStatement("insert into RegisteredUsers(firstname,lastname,password,gender,skillset,city) values(?,?,?,?,?,?)");
			pstmt.setString(1, User.getFirstname());
			pstmt.setString(2, User.getLastname());
			pstmt.setString(3, User.getPassword());
			pstmt.setString(4, User.getGender());
			pstmt.setString(5, User.getSkillset());
			pstmt.setString(6, User.getCity());
			
			 count=pstmt.executeUpdate();
			if(count<=0)
			{
				throw new RegistrationException("Insertion Fail");
			}
			/*PreparedStatement pstmt2=con.prepareStatement("select reg_seq.currval from dual");
			ResultSet rst=pstmt2.executeQuery();
			if(rst.next())
			{
				id=rst.getInt(1);
				
			}
			else
			{
				throw new RegistrationException("Sequence not found or unable to get seq. number");
			}*/
		} 
		catch (SQLException e) 
		{

			e.printStackTrace();
		}
	return count;
	}

	/*@Override
		public List<RegistrationDto> viewAllUsers() throws RegistrationException {
		List<RegistrationDto> list = new ArrayList<RegistrationDto>();
		Connection con=DbConnection.getConnection();
		try 
		{
			PreparedStatement pstmt = con.prepareStatement("select firstname,lastname,password,gender,skillset,city from RegisteredUsers");
			
			ResultSet rst = pstmt.executeQuery();
			
			while(rst.next())
			{
				RegistrationDto dto = new RegistrationDto();
				
				
				dto.setFirstname(rst.getString("fname"));
				dto.setLastname(rst.getString("lame"));
				dto.setPassword(rst.getString("pass"));
				dto.setGender(rst.getString("gdr"));
				dto.setSkillset(rst.getString("sklset"));
				dto.setCity(rst.getString("city"));
				list.add(dto);
			}
		} 
		catch (SQLException e) 
		{
			
			e.printStackTrace();
		}
		
		return (list);
		
	}*/
	
}
