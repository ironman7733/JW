package com.cg.trainee.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.trainee.bean.TraineeBean;



@Repository
@Transactional
public class TraineeDaoImpl implements ITraineeDao
{

	@PersistenceContext
	private EntityManager entityManager;
	
	
	@Override
	public TraineeBean addTrainee(TraineeBean trainee) 
	{
		entityManager.persist(trainee);
		entityManager.flush();
		return trainee;
	}


	@Override
	public List<TraineeBean> getAllTraineeDetails() 
	{
		TypedQuery<TraineeBean> query = entityManager.createQuery("SELECT t FROM TraineeBean t", TraineeBean.class);
		return query.getResultList();
	}


	@Override
	public TraineeBean getTraineeDetails(int traineeId) 
	{
		return entityManager.find(TraineeBean.class, traineeId);
	}

	@Override
	public void updateTrainee(TraineeBean trainee) 
	{
		entityManager.merge(trainee);
	}


	@Override
	public void deleteTrainee(TraineeBean trainee) 
	{
		entityManager.remove(trainee);
	}

}
