package com.cg.trainee.dao;

import java.util.List;
import com.cg.trainee.bean.TraineeBean;




public interface ITraineeDao 
{

	public TraineeBean addTrainee(TraineeBean trainee);
	public List<TraineeBean> getAllTraineeDetails();
	public TraineeBean getTraineeDetails(int traineeId);
	//public boolean modifyTrainee(int traineeId, String traineeName, String traineeLocation, String traineeDomain);
	public void updateTrainee(TraineeBean trainee);
	public void deleteTrainee(TraineeBean trainee);
}
