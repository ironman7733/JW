package com.cg.trainee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.trainee.bean.TraineeBean;
import com.cg.trainee.dao.ITraineeDao;

@Service
public class TraineeServiceImpl implements ITraineeService
{

	@Autowired
	ITraineeDao traineeDao;
	
	public ITraineeDao getTraineeDao(){
		return traineeDao;
	}

	public void setTraineeDao(ITraineeDao traineeDao) 
	{
		this.traineeDao = traineeDao;
	}

	@Override
	public TraineeBean addTrainee(TraineeBean trainee) 
	{
		return traineeDao.addTrainee(trainee);
	}

	@Override
	public List<TraineeBean> getAllTraineeDetails() 
	{
		return traineeDao.getAllTraineeDetails();
	}

	@Override
	public TraineeBean getTraineeDetails(int traineeId) 
	{
		return traineeDao.getTraineeDetails(traineeId);
	}

	@Override
	public void updateTrainee(TraineeBean trainee) 
	{
		traineeDao.updateTrainee(trainee);
		
	}

	@Override
	public void deleteTrainee(TraineeBean trainee) 
	{
		traineeDao.deleteTrainee(trainee);
	}

	

}
