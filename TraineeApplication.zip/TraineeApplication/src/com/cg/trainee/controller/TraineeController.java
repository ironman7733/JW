package com.cg.trainee.controller;
 

import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import com.cg.trainee.bean.LoginBean;
import com.cg.trainee.bean.TraineeBean;
import com.cg.trainee.service.ITraineeService;




@Controller
public class TraineeController 
{
	
	@Autowired
	private ITraineeService traineeService;
	
	public ITraineeService getTraineeService() 
	{
		return traineeService;
	}
	
	public void setTraineeService(ITraineeService traineeService) 
	{
		this.traineeService = traineeService;
	}
	

	@RequestMapping("/showIndex")
	public String showIndexPage() 
	{

		return "index";
	}
	
	
	

	@RequestMapping("/showHomePage")
	public ModelAndView showHomePage() 
	{
		// Create an attribute of type Question
		LoginBean login = new LoginBean();
		// Add the attribute to the model and set the viewname and return it
		return new ModelAndView("login", "login", login);
	}
 
	
	@RequestMapping("/verify")
    public String submit(Model model, @ModelAttribute("loginBean") LoginBean loginBean) 
    {
	
		
        if (loginBean != null && loginBean.getUsername() != null & loginBean.getPassword() != null) 
        {
            if (loginBean.getUsername().equals("admin") && loginBean.getPassword().equals("admin123")) 
            {
                model.addAttribute("msg", "welcome" + loginBean.getUsername());
                return "index";
            } 
            else 
            {
                model.addAttribute("error", "Invalid Details");
                return "error";
            }
        } 
        else 
        {
            model.addAttribute("error", "Please enter Details");
            return "login";
        }
    }
	
	@RequestMapping("/showAddTraineeForm")
	public ModelAndView showAddTrainee() 
	{
		// Create an attribute of type Question
		TraineeBean trainee = new TraineeBean();
		// Add the attribute to the model and set the viewname and return it
		return new ModelAndView("addTraineeForm", "trainee", trainee);
	}

	@RequestMapping("/addTrainee")
	public ModelAndView addTrainee(
			@ModelAttribute("trainee") @Valid TraineeBean trainee,
			BindingResult result) 
	{

		ModelAndView mv = null;

		if (!result.hasErrors()) 
		{
			trainee = traineeService.addTrainee(trainee);
			mv = new ModelAndView("success");
		} 
		else 
		{
			mv = new ModelAndView("addTraineeForm", "trainee", trainee);
		}

		return mv;
	}
	
	
	
	
	@RequestMapping("/retrieveAllTraineesForm")
	public ModelAndView showViewAllTrainees() {

		ModelAndView mv = new ModelAndView();

		List<TraineeBean> list = traineeService.getAllTraineeDetails();
		if (list.isEmpty()) 
		{
			String msg = "There are no Trainees";
			mv.setViewName("error");
			mv.addObject("msg", msg);
		} 
		else 
		{
			mv.setViewName("retrieveAllTraineesList");
			// Add the attribute to the model
			mv.addObject("list", list);
		}
		return mv;
	}
	
	
	
	@RequestMapping("/retrieveTraineeForm")
	public ModelAndView showViewTraineeForm() 
	{

		// Create an attribute of type Question
		TraineeBean trainee = new TraineeBean();
		// Add the attribute to the model and return along with
		// the view name
		ModelAndView mv = new ModelAndView("viewTrainee");
		mv.addObject("trainee", trainee);
		mv.addObject("isFirst", "true");

		return mv;
		//return new ModelAndView("viewTrainee", "trainee", trainee);
	}

	@RequestMapping("/viewTrainee")
	public ModelAndView viewTrainee(@ModelAttribute("trainee") TraineeBean trainee) {

		ModelAndView mv = new ModelAndView();

		TraineeBean tBean = new TraineeBean();
		tBean = traineeService.getTraineeDetails(trainee.getTraineeId());

		if (tBean != null) 
		{
			mv.setViewName("viewTrainee");
			mv.addObject("tBean", tBean);
		} 
		else 
		{
			String msg = "Enter a Valid Id!!";
			mv.setViewName("error");
			mv.addObject("msg", msg);
		}

		return mv;
	}
	
	
	
	
	@RequestMapping("/modifyTraineeForm")
	public ModelAndView showModifyForm() 
	{
		// Create an attribute of type Question
		TraineeBean trainee = new TraineeBean();
		return new ModelAndView("modify","trainee",trainee);
	}
	@RequestMapping("/modifyTrainee")
	public ModelAndView viewTraineeToModify(@ModelAttribute("trainee") TraineeBean trainee) 
	{
		ModelAndView mv = new ModelAndView();
		// Create an attribute of type Question
		TraineeBean trainee1 = new TraineeBean();
		trainee1 = traineeService.getTraineeDetails(trainee.getTraineeId());
		if(trainee1 != null)
		{
			mv.setViewName("modify");
			mv.addObject("trainee1",trainee1);
		}
		else
		{
			String msg = "Enter a valid Id!";
			mv.setViewName("error");
			mv.addObject("msg",msg);
		}
		
		return mv;
	}
	@RequestMapping("/modify")
	public ModelAndView modifyTrainee(@ModelAttribute("trainee") TraineeBean trainee) 
	{

		ModelAndView mv = new ModelAndView();
		TraineeBean trainee1 = new TraineeBean();
		trainee1 = traineeService.getTraineeDetails(trainee.getTraineeId());
		if (trainee1 != null) 
		{
			traineeService.updateTrainee(trainee);
			mv.setViewName("success");
			mv.addObject("traineeId",trainee1.getTraineeId());
		} 
		else 
		{
			String msg = "Enter a valid Id!";
			mv.setViewName("error");
			mv.addObject("msg",msg);
		}

		return mv;
		
	}
	
	
	@RequestMapping("/showDeleteForm")
	public ModelAndView showDeleteForm() 
	{
		// Create an attribute of type Question
		TraineeBean trainee = new TraineeBean();
		ModelAndView mv = new ModelAndView("deleteTraineeForm");
		mv.addObject("trainee", trainee);
		mv.addObject("isFirst", "true");
		return mv;
	}
	@RequestMapping("/deleteTrainee")
	public ModelAndView viewTraineeToDelete(@ModelAttribute("trainee") TraineeBean trainee) 
	{
		ModelAndView mv = new ModelAndView();
		// Create an attribute of type Question
		TraineeBean trainee1 = new TraineeBean();
		trainee1 = traineeService.getTraineeDetails(trainee.getTraineeId());
		if(trainee1 != null)
		{
			mv.setViewName("deleteTraineeForm");
			mv.addObject("trainee1",trainee1);
		}
		else
		{
			String msg = "Enter a valid Id!";
			mv.setViewName("error");
			mv.addObject("msg",msg);
		}
		
		return mv;
	}
	
	@RequestMapping("/delete")
	public ModelAndView deleteTrainee(@ModelAttribute("trainee") TraineeBean trainee) 
	{

		ModelAndView mv = new ModelAndView();
		TraineeBean trainee1 = new TraineeBean();
		trainee1 = traineeService.getTraineeDetails(trainee.getTraineeId());
		if (trainee1 != null) 
		{
			traineeService.deleteTrainee(trainee1);
			mv.setViewName("success");
			mv.addObject("traineeId",trainee1.getTraineeId());
		} 
		else 
		{
			String msg = "Enter a valid Id!";
			mv.setViewName("error");
			mv.addObject("msg",msg);
		}

		return mv;
		
	}
}