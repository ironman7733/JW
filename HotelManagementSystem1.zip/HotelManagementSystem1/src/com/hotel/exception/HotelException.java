package com.hotel.exception;

public class HotelException {

}
