package com.hotel.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.hotel.beans.HotelBean;
import com.hotel.service.IHotelService;
@Controller
public class HotelController 
{

	@Autowired
	private IHotelService service;
	
	@RequestMapping("/showHomePage")
	public String showHomePage() 
	{
		return "index";
	}
	
	@RequestMapping("/showRegisterHotelForm")
	public ModelAndView showRegisterHotelForm() 
	{
		HotelBean bean = new HotelBean();
		ModelAndView mv = new ModelAndView("registerHotelForm");
		mv.addObject("bean", bean);
		mv.addObject("isFirst", "true");
		return mv;
	}
	
	@RequestMapping("/registerHotelForm")
	public ModelAndView viewDonation(@ModelAttribute("bean")@Valid HotelBean bean,
			BindingResult result) 
	{

		ModelAndView mv = new ModelAndView();
		HotelBean hBean = new HotelBean();
		if (!result.hasErrors()) 
		{
			hBean =service.getHotelDetails(bean.getHotelName(),bean.getCity());
			if (hBean!=null) 
			{
				mv.setViewName("registerHotelForm");
				mv.addObject("hBean", hBean);
			} 
			else 
			{
				String msg = "Details not in the database.";
				mv.setViewName("errorpage");
				mv.addObject("msg", msg);
			}
		}
		else
		{
			mv = new ModelAndView("registerHotelForm", "bean", bean);
		}
		return mv;
	}
	
	@RequestMapping(value = "/bookHotel", method=RequestMethod.GET)
	public ModelAndView bookHotel(@RequestParam("hotelId") int hotelId) 
	{

		ModelAndView mv = new ModelAndView();
		if (service.bookHotel(hotelId)) 
		{
			mv.setViewName("success");
		} 
		else 
		{
			mv.setViewName("failure");
		}
		return mv;
	}
}
