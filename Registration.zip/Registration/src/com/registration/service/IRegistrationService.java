package com.registration.service;

import com.registration.dto.RegistrationDto;
import com.registration.exception.RegistrationException;

public interface IRegistrationService 
{
	
	public int addUser(RegistrationDto User) throws RegistrationException;
}
