package com.capgemini.hbms.service;


import java.util.List;

import com.capgemini.hbms.bean.Hotel;
import com.capgemini.hbms.bean.RoomDetails;
import com.capgemini.hbms.bean.Users;
import com.capgemini.hbms.exception.HotelException;

public interface IHotelService {

	//verify admin login function
		public boolean verifyLogin(int id,String password) throws HotelException;
		public boolean verifyCustLogin(int id,String password) throws HotelException;
		
	//Admin operations
		public int addHotel(Hotel hotel) throws HotelException;
		public boolean deleteHotel(int hotelId) throws HotelException;
		public boolean modifyHotel(String hotelDesc,double avgRate,int hotelId) throws HotelException;
	
	//Room operations
		public int addRoom(RoomDetails room) throws HotelException;
		public boolean deleteRoom(int roomId) throws HotelException;
		public boolean modifyRoom(int roomId,double rent) throws HotelException;
		
	//Generate Lists 
		public List<Hotel> getHotelList() throws HotelException;	
		public List<Users> getGuestListByHotel_Id(int hotel_id) throws HotelException;
		
}
