package com.capgemini.hbms.ui;

public enum AdminMenu {

	MANAGE_HOTELS,MANAGE_ROOMS,GENERATE_REPORTS,EXIT;
}
