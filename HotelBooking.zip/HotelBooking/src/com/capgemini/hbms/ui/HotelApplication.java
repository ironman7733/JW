package com.capgemini.hbms.ui;

import java.util.List;
import java.util.Scanner;

import org.apache.log4j.PropertyConfigurator;

import com.capgemini.hbms.bean.Hotel;
import com.capgemini.hbms.bean.RoomDetails;

import com.capgemini.hbms.exception.HotelException;
import com.capgemini.hbms.service.HotelServiceImpl;
import com.capgemini.hbms.service.IHotelService;

public class HotelApplication {

	public static void main(String[] args) {

		IHotelService service = new HotelServiceImpl();
		Scanner scanner = new Scanner(System.in);
		PropertyConfigurator.configure("resources/log4j.properties");

		UserMenu choice = null;
		AdminMenu adminChoice = null;
		CustomerMenu custChoice = null;
		CustomerLoginMenu custLoginChoice = null;
		int operation = 0;

		try {
			while (choice != UserMenu.EXIT) {
				System.out
						.println("************  HOTEL BOOKING MANAGEMENT SYSTEM  **************");
				System.out.println("CHOICE\t MENU");
				System.out
						.println("***********************************************************");
				for (UserMenu menuItem : UserMenu.values()) {
					System.out.println(menuItem.ordinal() + "\t"
							+ menuItem.name());
				}

				System.out.println("Enter Choice: ");
				int ordinal = scanner.nextInt();
				if (ordinal < 0 || ordinal > UserMenu.EXIT.ordinal()) {
					System.err.println("Invalid Choice");
					continue;
				}

				choice = UserMenu.values()[ordinal];

				switch (choice) {

				case ADMIN:

					System.out.println("Enter your UserId:");
					int adminId = scanner.nextInt();
					System.out.println("Enter your Password");
					String adminPassword = scanner.next();

					boolean loginStatus = service.verifyLogin(adminId,
							adminPassword);
					if (loginStatus == true) {

						while (adminChoice != AdminMenu.EXIT) {
							System.out.println("CHOICE\t MENU");
							System.out
									.println("***********************************************************");
							for (AdminMenu menuItem : AdminMenu.values()) {
								System.out.println(menuItem.ordinal() + "\t"
										+ menuItem.name());
							}

							System.out.println("Enter Choice: ");
							int ordinal1 = scanner.nextInt();
							if (ordinal1 < 0
									|| ordinal1 > AdminMenu.EXIT.ordinal()) {
								System.err.println("Invalid Choice");
								continue;
							}

							adminChoice = AdminMenu.values()[ordinal1];

							switch (adminChoice) {

							case MANAGE_HOTELS:
								System.out.println(adminChoice);
								while (operation < 4) {
									System.out.println("Choices");
									System.out.println("1.Add Hotel\n"
											+ "2.Delete Hotel\n"
											+ "3.Modify Hotel\n" + "4.Exit\n");
									System.out.println("Enter Operations!!!");
									operation = scanner.nextInt();
									switch (operation) {

									case 1:

										Hotel hotel = new Hotel();

										System.out.println("Enter Hotel Name");
										hotel.setHotelName(scanner.next());
										System.out.println("Enter City");
										hotel.setCity(scanner.next());
										System.out.println("Enter Address");
										hotel.setAddress(scanner.next());
										System.out.println("Enter Description");
										hotel.setDescription(scanner.next());
										System.out
												.println("Enter Average Rate Per night");
										hotel.setAvgRatePerNight(scanner
												.nextDouble());
										System.out.println("Enter Phone No 1 ");
										hotel.setPhoneNo1(scanner.next());
										System.out.println("Enter Phone No 2 ");
										hotel.setPhoneNo2(scanner.next());
										System.out
												.println("Enter Rating On A scale of 5");
										hotel.setRating(scanner.nextInt());
										System.out.println("Enter Email");
										hotel.setEmail(scanner.next());
										System.out.println("Enter Fax");
										hotel.setFax(scanner.next());
										try {
											int curr_id = service
													.addHotel(hotel);
											if (curr_id > 0) {
												System.out
														.println("Hotel Added with HotelId: "
																+ curr_id
																+ " .");
											} else {
												System.out
														.println("Hotel could not be added");
											}
										} catch (HotelException exp) {
											System.err
													.println(exp.getMessage());
										}
										break;

									case 2:

										try {
											System.out.println("Enter HotelId");
											int hotelId = scanner.nextInt();
											boolean isSuccessful = service
													.deleteHotel(hotelId);
											if (isSuccessful) {
												System.out
														.println("Hotel Deleted");
											} else {
												System.out
														.println("Hotel could not be deleted");
											}

										} catch (HotelException exp) {
											System.err
													.println(exp.getMessage());
										}
										break;

									case 3:
										System.out.println("modify");
										System.out
												.println("Enter the hotel id you want to update");
										int hid = scanner.nextInt();
										System.out
												.println("Enter Updated Description");
										String hotelDesc = scanner.next();
										System.out
												.println("Enter Updated Average Rate Per night");
										double avgRate = scanner.nextDouble();
										try {
											boolean isSuccessful = service
													.modifyHotel(hotelDesc,
															avgRate, hid);
											if (isSuccessful) {
												System.out
														.println("Hotel Modified");
											} else {
												System.out
														.println("Hotel could not be modified");
											}

										} catch (HotelException exp) {
											System.err
													.println(exp.getMessage());
										}
										break;

									case 4:
										break;
									}
								}
								operation = 0;
								break;

							case MANAGE_ROOMS:
								while (operation < 4) {
									System.out.println("Choices");
									System.out.println("1.Add Room\n"
											+ "2.Delete Room\n"
											+ "3.Modify Room\n" + "4.Exit\n");
									System.out.println("Enter Operations!!!");
									operation = scanner.nextInt();
									switch (operation) {
									case 1:

										RoomDetails room = new RoomDetails();

										System.out.println("Enter Hotel Id");
										room.setHotelId(scanner.nextInt());
										System.out.println("Enter Room No");
										room.setRoomNo(scanner.nextInt());
										System.out.println("Enter Room Type");
										room.setRoomType(scanner.next());
										System.out
												.println("Enter Rate Per Night");
										room.setPerNightRate(scanner
												.nextDouble());
										System.out.println("Availability");
										room.setAvailability(scanner.nextInt());
										try {
											int curr_id = service.addRoom(room);
											if (curr_id > 0) {
												System.out
														.println("Room Added with RoomId: "
																+ curr_id
																+ " .");
											} else {
												System.out
														.println("Room could not be added");
											}
										} catch (HotelException exp) {
											System.err
													.println(exp.getMessage());
										}
										break;
									case 2:

										try {
											System.out.println("Enter RoomId");
											int roomId = scanner.nextInt();
											boolean isSuccessful = service
													.deleteRoom(roomId);
											if (isSuccessful) {
												System.out
														.println("Room Deleted");
											} else {
												System.out
														.println("Room could not be deleted");
											}

										} catch (HotelException exp) {
											System.err
													.println(exp.getMessage());
										}
										break;
									case 3:

										try {
											System.out.println("Enter RoomId");
											int roomId = scanner.nextInt();
											System.out
													.println("Enter Revised Tariff");
											double rent = scanner.nextDouble();
											boolean isSuccessful = service
													.modifyRoom(roomId, rent);
											if (isSuccessful) {
												System.out
														.println("Room Updated");
											} else {
												System.out
														.println("Room could not be updated");
											}

										} catch (HotelException exp) {
											System.err
													.println(exp.getMessage());
										}
										break;
									case 4:
										break;
									}
								}
								operation = 0;
								break;

							case GENERATE_REPORTS:
								while (operation < 5) {
									System.out.println("Choices");
									System.out.println("1.List Of Hotels\n"
											+ "2.Exit\n");
									System.out.println("Enter Operations....");
									operation = scanner.nextInt();
									switch (operation) {
									case 1:

										try {
											List<Hotel> hotels = service
													.getHotelList();
											System.out
													.println("******************************************************************HOTEL DETAILS*****************************************************************************");
											System.out
													.println("************************************************************************************************************************************************************");
											System.out.println("HOTEL ID"
													+ "\t" + "HOTEL NAME"
													+ "\t" + "CITY" + "\t\t"
													+ "ADDRESS" + "\t\t"
													+ "DESCRIPTION" + "\t"
													+ "RATE PER NIGHT" + "\t"
													+ "PHONE 01" + "\t"
													+ "PHONE 02" + "\t"
													+ "RATING" + "\t" + "EMAIL"
													+ "\t\t" + "FAX");
											System.out
													.println("-------------------------------------------------------------------------------------------------------------------------------------------------------------");
											for (Hotel hotel2 : hotels) {
												System.out.println(hotel2);
											}
										} catch (HotelException exp) {
											System.err
													.println(exp.getMessage());
										}
										break;
									
									case 2:
										break;
									}
								}
								operation = 0;
								break;

							case EXIT:
								break;

							}
						}
					} else {
						System.out.println("Unauthorised Access!!!");
					}
					break;

				case CUSTOMER:
					while (custChoice != CustomerMenu.EXIT) {
						System.out.println("CHOICE\t MENU");
						System.out
								.println("***********************************************************");
						for (CustomerMenu menuItem : CustomerMenu.values()) {
							System.out.println(menuItem.ordinal() + "\t"
									+ menuItem.name());
						}

						System.out.println("Enter Choice: ");
						int ordinal1 = scanner.nextInt();
						if (ordinal1 < 0
								|| ordinal1 > CustomerMenu.EXIT.ordinal()) {
							System.err.println("Invalid Choice");
							continue;
						}

						custChoice = CustomerMenu.values()[ordinal1];

						switch (custChoice) {

						case LOGIN:

							System.out.println("Enter your UserId:");
							int userId = scanner.nextInt();
							System.out.println("Enter your Password");
							String userPassword = scanner.next();

							boolean loginStatusUser = service.verifyCustLogin(
									userId, userPassword);
							if (loginStatusUser == true) {
								while (custLoginChoice != CustomerLoginMenu.EXIT) {
									System.out.println("CHOICE\t MENU");
									System.out
											.println("***********************************************************");
									for (CustomerLoginMenu menuItem : CustomerLoginMenu
											.values()) {
										System.out.println(menuItem.ordinal()
												+ "\t" + menuItem.name());
									}

									System.out.println("Enter Choice: ");
									int ordinal2 = scanner.nextInt();
									if (ordinal2 < 0
											|| ordinal2 > CustomerLoginMenu.EXIT
													.ordinal()) {
										System.err.println("Invalid Choice");
										continue;
									}

									custLoginChoice = CustomerLoginMenu
											.values()[ordinal2];

								}
							} else {
								System.out.println("Unauthorised Access!!!");
							}
							break;
						case EXIT:
							break;
						}
					}
					break;

				case EXIT:
					System.exit(0);
				}

			}

		} catch (HotelException e) {
			System.out.println(e.getMessage());
		}
	}
}
