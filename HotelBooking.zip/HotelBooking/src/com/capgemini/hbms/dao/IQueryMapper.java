package com.capgemini.hbms.dao;


public interface IQueryMapper {
	
	
	//Admin login verification query
	public final  String GET_ADMIN = "SELECT user_id,password FROM users WHERE role = 'admin' AND user_id=?";
	
	//Admin operations queries
	
	// Hotel Operations
	public static final String INSERT_INTO_HOTEL = " INSERT INTO hotel(hotel_id,city,hotel_name,address,description,avg_rate_per_night,phone_no1,phone_no2,rating,email,fax)"
			+ "VALUES (hotel_id_seq.nextval,?,?,?,?,?,?,?,?,?,?)";
	
	public static final String DELETE_HOTEL = " DELETE FROM hotel WHERE hotel_id = ? ";
	
	public static final String UPDATE_HOTEL = " UPDATE hotel SET description=?,avg_rate_per_night=? WHERE hotel_id=? " ;
	
	public static final String GET_CURRVAL_HOTEL = "SELECT hotel_id_seq.currval FROM DUAL";
	
	
	// Room operations
	
	public static final String INSERT_INTO_ROOM = " INSERT INTO roomdetails(hotel_id,room_id,room_no,room_type,per_night_rate,availability)"
			+ "VALUES (?,room_id_seq.nextval,?,?,?,?)";
	
	public static final String GET_CURRVAL_ROOM = "SELECT room_id_seq.currval FROM DUAL";
	
	public static final String DELETE_ROOM = " DELETE FROM roomdetails WHERE room_id = ? ";
	
	public static final String UPDATE_ROOM = " UPDATE roomdetails SET per_night_rate=? WHERE room_id = ? " ;
	
	// Generate List
	
	public static final String GET_HOTEL_LIST = "SELECT hotel_id,city,hotel_name,address,description,avg_rate_per_night,phone_no1,phone_no2,rating,email,fax FROM hotel";
	
	
	//Customer Login
	public final  String GET_USER = "SELECT user_id ,password FROM users WHERE role = 'CUSTOMER' AND user_id =?";
	
	

	
	//Guest List
	public static final String GUEST_LIST_BY_HOTEL_ID = "SELECT DISTINCT ud.user_id,ud.user_name FROM USERS ud JOIN bookingdetails bd ON bd.user_id=ud.user_id JOIN roomdetails rd ON rd.room_id=bd.room_id WHERE hotel_id=?";
}
