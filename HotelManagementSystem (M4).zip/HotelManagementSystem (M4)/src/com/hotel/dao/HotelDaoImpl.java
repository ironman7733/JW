package com.hotel.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;



import com.hotel.beans.HotelBean;
@Repository
@Transactional(rollbackOn = Exception.class)
public class HotelDaoImpl implements IHotelDao {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public HotelBean getHotelDetails(String hotelName, String hotelCity) {
		TypedQuery<HotelBean> qry = entityManager.createQuery("from HotelBean where hotelName=? and city=?",HotelBean.class);
		qry.setParameter(1,hotelName);
		qry.setParameter(2,hotelCity);
		HotelBean bean = qry.getSingleResult();
		return bean;
	}

	@Override
	public boolean bookHotel(int hotelId) {
		boolean flag= false;
		HotelBean bean = entityManager.find(HotelBean.class,hotelId);
		if(bean!=null){
			bean.setBookingStatus('Y');
			
		flag = true;
		}
		else{
			flag = false;
		}
		entityManager.merge(bean);
		return flag;
	}

}
