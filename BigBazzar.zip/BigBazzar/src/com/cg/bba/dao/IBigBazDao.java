package com.cg.bba.dao;

import java.util.List;

import com.cg.bba.beans.Products;
import com.cg.bba.beans.Transaction;

public interface IBigBazDao {
	
	public Products getProductById(int productId);
	public List<Transaction> getTransList(int productId);
	
}
