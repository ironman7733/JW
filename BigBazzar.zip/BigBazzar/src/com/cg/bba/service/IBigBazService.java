package com.cg.bba.service;

import java.util.List;

import com.cg.bba.beans.Products;
import com.cg.bba.beans.Transaction;

public interface IBigBazService {

	public Products getProductById(int productId);
	public List<Transaction> getTransList(int productId);
	
}
