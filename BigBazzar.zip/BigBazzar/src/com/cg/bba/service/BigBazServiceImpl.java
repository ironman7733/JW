package com.cg.bba.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bba.beans.Products;
import com.cg.bba.beans.Transaction;
import com.cg.bba.dao.IBigBazDao;

@Service
@Transactional
public class BigBazServiceImpl implements IBigBazService{

	@Autowired
	IBigBazDao dao;
		
	public IBigBazDao getDao() {
		return dao;
	}

	public void setDao(IBigBazDao dao) {
		this.dao = dao;
	}

	@Override
	public Products getProductById(int productId) {
		return dao.getProductById(productId);
	}

	@Override
	public List<Transaction> getTransList(int productId) {
		return dao.getTransList(productId);
	}

	
}
