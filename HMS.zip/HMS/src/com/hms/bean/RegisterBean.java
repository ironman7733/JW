package com.hms.bean;

public class RegisterBean 
{

	
	private String userName;
	private String password;
	private String fullName;
	private String role;
	private long mobileNo;
	private String address;
	private String emailId;
	
	public RegisterBean(String userName, String password, String fullName,
			String role, long mobileNo, String address, String emailId) 
	{
		super();
		this.userName = userName;
		this.password = password;
		this.fullName = fullName;
		this.role = role;
		this.mobileNo = mobileNo;
		this.address = address;
		this.emailId = emailId;
	}
	
	
	public RegisterBean() 
	{
		super();
		// TODO Auto-generated constructor stub
	}


	public String getUserName() 
	{
		return userName;
	}
	public void setUserName(String userName) 
	{
		this.userName = userName;
	}
	public String getPassword() 
	{
		return password;
	}
	public void setPassword(String password) 
	{
		this.password = password;
	}
	public String getFullName() 
	{
		return fullName;
	}
	public void setFullName(String fullName) 
	{
		this.fullName = fullName;
	}
	public String getRole() 
	{
		return role;
	}
	public void setRole(String role) 
	{
		this.role = role;
	}
	public long getMobileNo() 
	{
		return mobileNo;
	}
	public void setMobileNo(long mobileNo) 
	{
		this.mobileNo = mobileNo;
	}
	public String getAddress() 
	{
		return address;
	}
	public void setAddress(String address) 
	{
		this.address = address;
	}
	public String getEmailId() 
	{
		return emailId;
	}
	public void setEmailId(String emailId) 
	{
		this.emailId = emailId;
	}


	@Override
	public String toString() {
		return "RegisterBean [userName=" + userName + ", password=" + password
				+ ", fullName=" + fullName + ", role=" + role + ", mobileNo="
				+ mobileNo + ", address=" + address + ", emailId=" + emailId
				+ "]";
	}
	
	
	
	
	
	
}
