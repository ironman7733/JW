package com.hms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.hms.bean.RegisterBean;
import com.hms.exception.RegisterException;
import com.hms.util.DBConnection;



public class RegisterDaoImpl implements IRegisterDao
{
	
	//private CustomerBean bean = new CustomerBean();

	@Override
	public void registerCustomer(RegisterBean bean) throws RegisterException 
	{
		
		Connection con=DBConnection.getConnection();
		String query = QueryMapper.INSERT_QUERY;
		try 
		{
			PreparedStatement pstmt=con.prepareStatement(query);
			
			pstmt.setString(1, bean.getUserName());
			pstmt.setString(2, bean.getPassword());
			pstmt.setString(3, bean.getFullName());
			pstmt.setString(4, bean.getRole());
			pstmt.setLong(5, bean.getMobileNo());
			pstmt.setString(6, bean.getAddress());
			pstmt.setString(7, bean.getEmailId());
			
			int count=pstmt.executeUpdate();
			if(count<=0)
			{
				
				throw new RegisterException("Insert failed... ");
			}
				
			con.close();
		}
		catch (SQLException e) 
		{
	
			throw new RegisterException(e.getMessage());
		}

	}
}

