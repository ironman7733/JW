package com.hms.dao;

import com.hms.bean.RegisterBean;
import com.hms.exception.RegisterException;



public interface IRegisterDao 
{
	
	public void registerCustomer(RegisterBean customer) throws RegisterException;

}
