package com.hms.dao;

public class QueryMapper 
{

	public static final String INSERT_QUERY="insert into users(username,password,fullname,role,mobileno,address,emailid) values(?,?,?,?,?,?,?)";	
}
