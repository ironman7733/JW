package com.hms.exception;

public class RegisterException extends Exception
{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3488477576766738054L;

	public RegisterException(String message)
	{
		super(message);
	}
}
