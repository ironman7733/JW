package com.hms.pl;

import java.util.Scanner;

import com.hms.bean.RegisterBean;
import com.hms.exception.RegisterException;
import com.hms.service.RegisterServiceImpl;
import com.hms.service.IRegisterService;



public class RegisterMain 
{

	public static void main(String[] args)
	{
		
		Scanner sc = new Scanner(System.in);
		IRegisterService registerService = new RegisterServiceImpl();
		System.out.println("-----Registering a Customer-----");
		
		System.out.println("Enter User Name:");
		String uname = sc.nextLine();
		System.out.println("Enter Password:");
		String pass = sc.nextLine();
		System.out.println("Enter Full Name:");
		String fname = sc.nextLine();
		System.out.println("Enter Role:");
		String role = sc.nextLine();
		System.out.println("Enter Mobile Number:");
		long mno = sc.nextLong();
		System.out.println("Enter Address:");sc.next();
		String addr = sc.nextLine();
		System.out.println("Enter EMail ID:");
		String mailid = sc.nextLine();
		
		
		RegisterBean register = new RegisterBean();
		register.setUserName(uname);
		register.setPassword(pass);
		register.setFullName(fname);
		register.setRole(role);
		register.setMobileNo(mno);
		register.setAddress(addr);
		register.setEmailId(mailid);
		System.out.println(register.toString());

		try 
		{
			registerService.registerCustomer(register);
			
			{
				System.out.println("You Have Registered Successfully");
				
			}
		} 
		catch (RegisterException e) 
		{
			System.out.println(e.getMessage());
		}

	}
}
