package com.hms.service;

import com.hms.bean.RegisterBean;
import com.hms.exception.RegisterException;



public interface IRegisterService 
{
	public void registerCustomer(RegisterBean customer) throws RegisterException;	

}
