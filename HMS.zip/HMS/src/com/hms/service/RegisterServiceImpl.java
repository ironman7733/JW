package com.hms.service;

import com.hms.bean.RegisterBean;
import com.hms.dao.RegisterDaoImpl;
import com.hms.dao.IRegisterDao;
import com.hms.exception.RegisterException;

public class RegisterServiceImpl implements IRegisterService
{
	
	private IRegisterDao registerDao=new RegisterDaoImpl();

	@Override
	public void registerCustomer(RegisterBean bean) throws RegisterException 
	{
		
		
		registerDao.registerCustomer(bean);
		
	}
}

