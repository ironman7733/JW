package com.cg.hbms.service;

import com.cg.hbms.entities.Users;
import com.cg.hbms.exception.HBMSException;

public interface UserService {
	public Users validateUser(Users user) throws HBMSException;
	
	public void registerUser(Users user) throws HBMSException;
}
