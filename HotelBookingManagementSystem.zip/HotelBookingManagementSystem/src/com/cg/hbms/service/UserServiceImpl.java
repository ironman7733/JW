package com.cg.hbms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.hbms.dao.UserDao;
import com.cg.hbms.entities.Users;
import com.cg.hbms.exception.HBMSException;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserDao dao;
	
	
	public UserDao getDao() {
		return dao;
	}


	public void setDao(UserDao dao) {
		this.dao = dao;
	}


	@Override
	public Users validateUser(Users user) throws HBMSException {
		// TODO Auto-generated method stub
		
		return dao.validateUser(user);
	}


	@Override
	public void registerUser(Users user) throws HBMSException {
		
		user.setRole("customer");
		dao.registerUser(user);
		
	}

}
