package com.cg.hbms.controller;


import java.util.Arrays;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.hbms.entities.Hotels;
import com.cg.hbms.entities.Rooms;
import com.cg.hbms.exception.HBMSException;
import com.cg.hbms.service.IAdminService;


@Controller
@RequestMapping("/*.adm")
public class HotelAdminController {

	@Autowired
	IAdminService service;
	
	public IAdminService getService() {
		return service;
	}

	public void setService(IAdminService service) {
		this.service = service;
	}
	
	@RequestMapping("/addHotelForm")
	public ModelAndView showAddHotelForm()
	{
		ModelAndView mv=null;
		Hotels hotel=new Hotels();
		mv= new ModelAndView("addHotelForm","hotel",hotel);
		mv.addObject("starlist", ratingList());
		return mv;
	}
	
	public List <String> ratingList(){
		
		return Arrays.asList("*","**","***","****","*****");
	}
	
	@RequestMapping("/persistHotel")
	public ModelAndView persistHotel(@ModelAttribute("hotel") @Valid Hotels hotel,BindingResult result) {
		
		ModelAndView mv = null;
		if(!result.hasErrors()){
		try {
			int id = service.persistHotel(hotel);
			if(id>0){
			mv = new ModelAndView("success", "id", id);
			mv.addObject("msg", "added successfully");
			}
			else{
				mv = new ModelAndView("success", "msg", "Failed to add Hotel");
			}
		} catch (HBMSException e) {
			mv = new ModelAndView("success", "msg", "Exception");
			e.printStackTrace();
		}
		}else
		{
			mv=new ModelAndView("addHotelForm","hotel",hotel);
		}
		return mv;
	}

	
	
	/*@RequestMapping("/addHotelForm")
	public ModelAndView showAddHotelForm()
	{
		Hotels hotel=new Hotels();
		ModelAndView mv=new ModelAndView("AddHotel","hotel",hotel);
		mv.addObject("starlist", ratingList());
		return mv;
		
	}
	
	

	@RequestMapping("/persistHotel")
	public ModelAndView persistHotel(@ModelAttribute("hotel") Hotels hotel) {
		
		System.out.println(hotel.getHotelEmail());
		ModelAndView mv = null;
		
		try {
			int id=service.persistHotel(hotel);
			mv=new ModelAndView("AddHotel","hotelId",id);
		} catch (HBMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		return mv;
	}
	*/
	
	@RequestMapping(value="/updateHotel",method=RequestMethod.GET)
	public ModelAndView showUpdateHotelForm(@RequestParam("id") int hotelId){
		
		Hotels hotel=new Hotels();
		hotel.setHotelId(hotelId);
		return new ModelAndView("updateHotelForm","hotel",hotel);
		
		
	}
	
	
	
	
	
	@RequestMapping("/modifyHotel")
	public ModelAndView updateHotel(@ModelAttribute("hotel")  @Valid Hotels hotel, BindingResult result){
		
		ModelAndView mv=null;
		
		if(!result.hasErrors()){
		try {
			int hId=service.updateHotel(hotel);
			mv=new ModelAndView("updatedSuccess","id",hId);
			mv.addObject("message", "Hotel Updated Successfully with Id: ");
			mv.addObject("check", "true");
		} catch (HBMSException e) {
			mv=new ModelAndView("updatedSuccess","message","OOps!! Exception Occured");
	
			e.printStackTrace();
		}
		}else{
			mv= new ModelAndView("updateHotelForm","hotel",hotel);
		}
		return mv;
		
	}

	@RequestMapping(value="/deleteHotel",method=RequestMethod.GET)
	public ModelAndView deleteHotel(@RequestParam("id") int hotelId){
		
		ModelAndView mv=null;
		
		try {
			int id=service.deleteHotel(hotelId);
			mv=new ModelAndView("deleteSuccess","id",id);
			mv.addObject("message", "Hotel deleted Succesfully having Id: ");
			mv.addObject("check", "true");
		} catch (HBMSException e) {
			mv=new ModelAndView("deleteSuccess","message","OOps!! something went wrong");
			
			e.printStackTrace();
		}
		
		return mv;
		
	}
	
	@RequestMapping(value="/showHotelPage",method=RequestMethod.GET)
	public ModelAndView showHotelDetailsPage(@RequestParam("id") int hotelId){
		
		Hotels hotel=null;
		List<Rooms> roomList=null;
		ModelAndView mv=null;
		try {
			hotel=service.getHotelById(hotelId);
			roomList=service.showRoomsList(hotelId);
			mv=new ModelAndView("ViewRooms","hotel",hotel);
			mv.addObject("roomData",roomList);
		} catch (HBMSException e) {
			mv=new ModelAndView("AdminPage","message","OOps!! something went wrong");
			e.printStackTrace();
		}
		
		return mv;
	}
	
	@RequestMapping(value="/AddRoom",method=RequestMethod.GET)
	public ModelAndView showAddRoomForm(@RequestParam("id") String hotelId){
		ModelAndView mv=null;
		mv=new ModelAndView("AddRoom","room",new Rooms());
		mv.addObject("hotelId", Integer.parseInt(hotelId));
		mv.addObject("roomTypeList", roomTypeList());
		mv.addObject("avaibilityList", availabilityList());
		
		return mv;
		
	}
	
	
	public List<String> roomTypeList()
	{
		return Arrays.asList("Suite Rooms","Executive Rooms","Prem A/C","Premium Non A/C");
	}
	
	public List<String> availabilityList(){
		return Arrays.asList("yes","no");
	}
	
	
	
	@RequestMapping("/ProcessAddRoomForm")
	public ModelAndView persistRoom(@RequestParam("id") int hotelId, @ModelAttribute("room") @Valid Rooms rooms, BindingResult result){
		
		ModelAndView mv=null;
		
		
		if(!result.hasErrors()){
		try {
			rooms.setHotelId(hotelId);
			int roomId=service.persistRoom(rooms);
			mv=new ModelAndView("AddRoomSuccess","roomId",roomId);
			mv.addObject("checkSuccess", "true");		
		} catch (HBMSException e) {
			mv=new ModelAndView("AddRoomSuccess","message","OOps!! Something went wrong..");
			mv.addObject("checkFailed", "true");	
			e.printStackTrace();
		}
		}
		else
		{
			mv=new ModelAndView("AddRoom","room",rooms);
			mv.addObject("hotelId",hotelId);
			mv.addObject("roomTypeList", roomTypeList());
			mv.addObject("avaibilityList", availabilityList());
				
		}
		return mv;
	}

}
