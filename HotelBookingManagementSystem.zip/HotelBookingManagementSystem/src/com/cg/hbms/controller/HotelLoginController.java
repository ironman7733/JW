package com.cg.hbms.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.hbms.entities.Hotels;
import com.cg.hbms.entities.Users;
import com.cg.hbms.exception.HBMSException;
import com.cg.hbms.service.AdminServiceImpl;
import com.cg.hbms.service.IAdminService;
import com.cg.hbms.service.UserService;


@Controller
@RequestMapping("/*.obj")
public class HotelLoginController {
	
	@Autowired
	UserService service;
	
	public UserService getService() {
		return service;
	}


	public void setService(UserService service) {
		this.service = service;
	}


	@RequestMapping("/showHomePage")
	public ModelAndView showHomepage()
	{
		Users user=new Users();
		return new ModelAndView("login","user",user);
		
		
	}
	
	
	@Autowired
	IAdminService admniService;
	
	
	

	
	public IAdminService getAdmniService() {
		return admniService;
	}


	public void setAdmniService(IAdminService admniService) {
		this.admniService = admniService;
	}


	@RequestMapping("/processLoginForm")
	public ModelAndView processLogin(@ModelAttribute("user")  Users user){
	
		ModelAndView mv=null;
		
			try {
				
				System.out.println("Inside try !!!!!");
				user=service.validateUser(user);
				System.out.println(user.getFullName());
				if(user.getRole().equalsIgnoreCase("admin"))
				{
					mv=new ModelAndView("AdminPage");
					List<Hotels> hotelList=null;
					hotelList=admniService.showHotelList();
					mv.addObject("hotelList", hotelList);
				}
				else if(user.getRole().equalsIgnoreCase("customer"))
				{
					mv=new ModelAndView("CustomerPage");
				}
				else
				{
					mv=new ModelAndView("login","message","Invalid username or password");
					mv.addObject("check", "true");
				}
			} catch (HBMSException e) {
				mv=new ModelAndView("login","user",user);
				mv.addObject("message", "Invalid username or password");
				mv.addObject("check", "true");
			}
		
		
		
		return mv;
		
	}
	
	
/*	@RequestMapping("/signUp")
	public ModelAndView showSignUp(){
		
		Users userData=new Users();
		return new ModelAndView("signUp","userSignUp",userData);
		
		
	}*/
	
	
	
	@RequestMapping("/registerUser")
	public ModelAndView registerUser(@ModelAttribute("user") @Valid Users userData,BindingResult result){
		
		ModelAndView mv=null;
		
		if(!result.hasErrors()){
			
			if(userData.getConfirmPassword().equals(userData.getPassword())){
				try {
					service.registerUser(userData);
					System.out.println("abcd");
					mv=new ModelAndView("SignUpStatus","message","Registered Successfully!!");
				} catch (HBMSException e) {
					mv=new ModelAndView("SignUpStatus","message",e.getMessage());
				}
			}else{
				
				mv= new ModelAndView("login","message","passwords do not match");
				mv.addObject("check", "true");
			}
			}
		else
		{
			mv=new ModelAndView("login","user",userData);
		}
		
		
		return mv;
	}
	
	@RequestMapping("/adminHomePage")
	public ModelAndView showAdminHomePage()
	{
		ModelAndView mv=null;
		List<Hotels> hotelList=null;
		try {
			hotelList=admniService.showHotelList();
			mv=new ModelAndView("AdminPage","hotelList",hotelList);
		} catch (HBMSException e) {
			mv=new ModelAndView("AdminPage","message","OOps!! Exception occured");
			mv.addObject("check", "true");
			e.printStackTrace();
		}
		
		return mv;
	}
}
