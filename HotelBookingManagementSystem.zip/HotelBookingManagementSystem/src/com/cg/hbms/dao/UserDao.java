package com.cg.hbms.dao;

import com.cg.hbms.entities.Users;
import com.cg.hbms.exception.HBMSException;

public interface UserDao {
	
	public Users validateUser(Users user) throws HBMSException;
	
	public void registerUser(Users user) throws HBMSException;

}
