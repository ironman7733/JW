package com.cg.hbms.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.hbms.entities.Users;
import com.cg.hbms.exception.HBMSException;

@Repository
@Transactional
public class UserDaoImpl implements UserDao {
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public Users validateUser(Users user) throws HBMSException {
		
	
		try {
			TypedQuery<Users> tQuery=entityManager.createQuery("FROM Users WHERE  userName=? AND password=?", Users.class);
			tQuery.setParameter(1, user.getUserName());
			tQuery.setParameter(2, user.getPassword());
			
			user=tQuery.getSingleResult();
			
		
		} catch (Exception e) {
			
			throw new HBMSException(e.getMessage());
			
		}
		return user;
		
	}

	@Override
	public void registerUser(Users user) throws HBMSException {
	
		Users userData=null;
		userData=entityManager.find(Users.class, user.getUserName());
		if(userData==null)
		{
			entityManager.persist(user);
			entityManager.flush();
		}
		else
		{
			throw new HBMSException("SignUp failed User name already exists");
		}
	}

}
