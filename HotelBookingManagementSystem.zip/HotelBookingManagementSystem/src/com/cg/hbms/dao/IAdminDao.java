package com.cg.hbms.dao;

import java.util.List;

import com.cg.hbms.entities.Hotels;
import com.cg.hbms.entities.Rooms;
import com.cg.hbms.exception.HBMSException;

public interface IAdminDao {

	public int persistHotel(Hotels hotel) throws HBMSException;
	
	public List<Hotels> showHotelList() throws HBMSException;
	
	public int updateHotel(Hotels hotel) throws HBMSException;
	
	public int deleteHotel(int hotelId) throws HBMSException;
	
	public Hotels getHotelById(int hotelId) throws HBMSException;
	
	public List<Rooms> showRoomsList(int hotelId) throws HBMSException;
	
	public int persistRoom(Rooms room) throws HBMSException;
}
