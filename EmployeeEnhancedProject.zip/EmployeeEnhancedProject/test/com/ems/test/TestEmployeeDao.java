package com.ems.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import com.emp.bean.EmployeeBean;
import com.emp.dao.EmployeeDaoImpl;
import com.emp.exception.EmployeeException;

public class TestEmployeeDao {
static EmployeeDaoImpl dao;
static EmployeeBean bean;

@BeforeClass
public static void init()
{
	dao=new EmployeeDaoImpl();
	bean = new EmployeeBean();
}
@Test
public void testAddEmployee()throws EmployeeException{
	bean.setEmployeeName("Amar");;
	bean.setEmployeeSalary(2300);
	int id=dao.addEmployee(bean);
	assertNotNull(dao.findEmployeeById(id));
}
}
