package com.cg.test;

import java.util.Arrays;

public class Test {

	public static void main(String[] args) 
	{
		int a = 0,b = 0;
		b = a++;
		System.out.println(a);
		System.out.println(b);
		int c = 2147483647;
		System.out.println(c);
		int d = 6;
		System.out.println(d);
		//int e[] = {1};
		//e[42] = 99;
		//Arrays.asList(e).indexOf(42);
		//String var = null;
		//System.out.println(var.length());
		System.out.println(2+3+"ram"+5+7);
		try
		{
			
		}
		finally
		{
			
		}
	}

}
