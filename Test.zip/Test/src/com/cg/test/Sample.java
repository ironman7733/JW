package com.cg.test;

interface Sample 
{

	int x = 10;
	void display();
	
}
