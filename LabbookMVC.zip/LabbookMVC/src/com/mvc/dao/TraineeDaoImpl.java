package com.mvc.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;




import com.mvc.beans.AdminBean;
import com.mvc.beans.TraineeBean;


@Repository
@Transactional(rollbackOn = Exception.class)
public class TraineeDaoImpl implements ITraineeDao {

	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public TraineeBean addTrainee(TraineeBean bean) {
		entityManager.persist(bean);
		entityManager.flush();
		return bean;
	}

	@Override
	public TraineeBean displayTraineeDetails(int traineeId) {
		return entityManager.find(TraineeBean.class, traineeId);
	}

	@Override
	public List<TraineeBean> displayAllTraineeDetails() {
		TypedQuery<TraineeBean> query = entityManager.createQuery("FROM TraineeBean", TraineeBean.class);
		return query.getResultList();
	}

	

	

	@Override
	public boolean deleteTrainee(int traineeId) {
		boolean flag= false;
		TraineeBean bean = entityManager.find(TraineeBean.class,traineeId);
		if(bean!=null){
			entityManager.remove(bean);
			
		flag = true;
		}
		else{
			flag = false;
		}
		return flag;
	}
	

	@Override
	public boolean modifyTrainee(int traineeId, String traineeName,
			String traineeDomain, String traineeLocation) {
	
		boolean flag= false;
		TraineeBean bean = entityManager.find(TraineeBean.class,traineeId);
		if(bean!=null){
			bean.setTraineeId(traineeId);
			bean.setTraineeName(traineeName);
			bean.setTraineeLocation(traineeLocation);
			bean.setTraineeDomain(traineeDomain);
			
		flag = true;
		}
		else{
			flag = false;
		}
		entityManager.merge(bean);
		return flag;
	}

	@Override
	public boolean login(String username, String password) {
		AdminBean bean = entityManager.find(AdminBean.class,username);
		boolean flag = false;
		if(bean!=null){
			if(bean.getPassword().equals(password)){
				flag = true;
			}
			else{
				flag=false;
			}
		}
		return flag;
	}

	
	
	}
	
	

