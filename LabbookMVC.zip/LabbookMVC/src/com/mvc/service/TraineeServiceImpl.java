package com.mvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



import com.mvc.beans.TraineeBean;
import com.mvc.dao.ITraineeDao;

@Service
public class TraineeServiceImpl implements ITraineeService {

	@Autowired
	ITraineeDao dao;
	
	
	
	public ITraineeDao getDao() {
		return dao;
	}

	public void setDao(ITraineeDao dao) {
		this.dao = dao;
	}

	@Override
	public TraineeBean addTrainee(TraineeBean bean) {
		return dao.addTrainee(bean);
	}

	@Override
	public TraineeBean displayTraineeDetails(int traineeId) {
		// TODO Auto-generated method stub
		return dao.displayTraineeDetails(traineeId);
	}

	@Override
	public List<TraineeBean> displayAllTraineeDetails() {
		// TODO Auto-generated method stub
		return dao.displayAllTraineeDetails();
	}

	@Override
	public boolean modifyTrainee(int traineeId, String traineeName,
			String traineeDomain, String traineeLocation) {
		// TODO Auto-generated method stub
		return dao.modifyTrainee(traineeId, traineeName, traineeDomain, traineeLocation);
	}

	@Override
	public boolean deleteTrainee(int traineeId) {
		// TODO Auto-generated method stub
		return dao.deleteTrainee(traineeId);
	}

	@Override
	public boolean login(String username, String password) {
		// TODO Auto-generated method stub
		return dao.login(username, password);
	}

}
