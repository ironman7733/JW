package com.mvc.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


import com.mvc.beans.AdminBean;
import com.mvc.beans.TraineeBean;
import com.mvc.service.ITraineeService;



@Controller
public class TraineeController {

	@Autowired
	private ITraineeService service;

	public ITraineeService getService() {
		return service;
	}

	public void setService(ITraineeService service) {
		this.service = service;
	}
	
	@RequestMapping("/showLogin")
	public ModelAndView showAddDonation() {
	
		AdminBean bean = new AdminBean();

		return new ModelAndView("login", "bean", bean);
	}
	

	@RequestMapping("/loginValidate")
	public ModelAndView loginValidate(	@ModelAttribute("bean") @Valid AdminBean bean,
			BindingResult result) {
		
		ModelAndView mv = null;
		if (!result.hasErrors()) {
			if(service.login(bean.getUsername(), bean.getPassword())){
				mv = new ModelAndView("index");
				
			}
			else{
				mv = new ModelAndView("loginFailure");
			}
		}
		else{
			mv = new ModelAndView("login", "bean", bean);
		}
		
		return mv;
		
		
	}

	@RequestMapping("/showIndex")
	public String showHomePage() {
		return "index";
	}
	
	
	@RequestMapping("/showAdd")
	public ModelAndView showAdd() {
	
		TraineeBean bean = new TraineeBean();

		return new ModelAndView("addTrainee", "bean", bean);
	}
	
	@RequestMapping("/addTrainee")
	public ModelAndView addTrainee(
			@ModelAttribute("bean") @Valid TraineeBean bean,
			BindingResult result) {

		ModelAndView mv = null;

		if (!result.hasErrors()) {
			bean = service.addTrainee(bean);
			mv = new ModelAndView("addSuccess");
			mv.addObject("traineeId", bean.getTraineeId());
			mv.addObject("traineeName", bean.getTraineeName());
		} else {
			mv = new ModelAndView("addTrainee", "bean", bean);
		}

		return mv;
	}
	
	
	@RequestMapping("/showDelete")
	public ModelAndView showDelete() {
	
		TraineeBean bean = new TraineeBean();
		
		ModelAndView mv = new ModelAndView("deleteTrainee", "bean", bean);
		mv.addObject("isFirst", "true");
		return mv;
	}
	

	
	@RequestMapping("/showTraineeDetails")
	public ModelAndView viewDonation(@ModelAttribute("bean") TraineeBean bean) {

		ModelAndView mv = new ModelAndView();

		bean = service.displayTraineeDetails(bean.getTraineeId());

		if (bean != null) {
			mv.setViewName("deleteTrainee");
			mv.addObject("bean", bean);
		} else {
			String msg = "Entered Id's not in the database!";
			mv.setViewName("myError");
			mv.addObject("msg", msg);
		}

		return mv;
	}
	
	@RequestMapping(value = "/deleteTrainee", method=RequestMethod.GET)
	public ModelAndView bookHotel(@RequestParam("tid") int traineeId) {
		
		
		ModelAndView mv = new ModelAndView();
		
		if (service.deleteTrainee(traineeId)) {
			
			mv.addObject("message", "The trainee details have been removed.");
			
			mv.setViewName("success");
		} else {
			mv.setViewName("failure");
		}
		
		return mv;
	}
	
	
	@RequestMapping("/showRetrieve")
	public ModelAndView showRetrieve() {
	
		TraineeBean bean = new TraineeBean();
		
		ModelAndView mv = new ModelAndView("retrieveTrainee", "bean", bean);
		mv.addObject("isFirst", "true");
		return mv;
	}
	
	
	@RequestMapping("/showRetrieveAll")
	public ModelAndView showRetrieveAll() {
	

			ModelAndView mv = new ModelAndView();

			List<TraineeBean> list = service.displayAllTraineeDetails();
			if (list.isEmpty()) {
				String msg = "There are no Trainers";
				mv.setViewName("myError");
				mv.addObject("msg", msg);
			} else {
				mv.setViewName("retrieveAllTrainee");
				mv.addObject("list", list);
			}
			return mv;
		}

	@RequestMapping("/showModify")
	public ModelAndView showModify() {
	
		TraineeBean bean = new TraineeBean();

		ModelAndView mv = new ModelAndView("modify", "bean", bean);
		 mv.addObject("isFirst", "true");
		return mv;
	}
	
	

	@RequestMapping("/modifyTrainee")
	public ModelAndView modifyTrainee() {
	
		TraineeBean bean = new TraineeBean();

		ModelAndView mv = new ModelAndView("modify", "bean", bean);
		return mv;
	}
	
	@RequestMapping("/modify")
	public ModelAndView modify(
			@ModelAttribute("bean") @Valid TraineeBean bean,
			BindingResult result) {

		ModelAndView mv = null;

		if (!result.hasErrors()) {
			if(service.modifyTrainee(bean.getTraineeId(), bean.getTraineeName(), bean.getTraineeDomain(), bean.getTraineeLocation())){
				
		
			mv = new ModelAndView("addSuccess");
			mv.addObject("traineeId", bean.getTraineeId());
			mv.addObject("traineeName", bean.getTraineeName());
			}
			else{
				String msg = "Couldn't modify.";
				  mv.setViewName("myError");
				  mv.addObject("msg", msg);
			}
		} else {
			mv = new ModelAndView("addTrainee", "bean", bean);
		}

		return mv;
	}
	

}



	

